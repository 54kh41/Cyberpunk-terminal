export interface Profile {
  id: string
  codename: string
  is_admin: boolean
  language_preference: "en" | "jp"
  avatar_url?: string
  bio_en?: string
  bio_jp?: string
  is_blocked?: boolean
  blocked_users?: string[]
  created_at: string
  updated_at: string
}

export interface Post {
  id: string
  author_id: string
  title_en: string
  title_jp: string | null
  content_en: string
  content_jp: string | null
  image_url: string | null
  video_url: string | null
  category: string
  is_pinned: boolean
  created_at: string
  updated_at: string
  profiles?: Profile
}

export interface Comment {
  id: string
  post_id: string
  author_id: string
  content_en: string
  content_jp: string | null
  created_at: string
  profiles?: Profile
}

export interface ChatMessage {
  id: string
  author_id: string
  content: string
  created_at: string
  profiles?: Profile
}

export interface AuthorSettings {
  id: string
  user_id: string
  banner_url?: string
  avatar_url?: string
  display_name_en?: string
  display_name_jp?: string
  bio_en?: string
  bio_jp?: string
  facebook_url?: string
  instagram_url?: string
  tiktok_url?: string
  twitter_url?: string
  youtube_url?: string
  discord_url?: string
  royal_road_url?: string
  kakuyomu_url?: string
  other_links?: { name: string; url: string }[]
  created_at: string
  updated_at: string
}

export interface FriendRequest {
  id: string
  sender_id: string
  receiver_id: string
  status: "pending" | "accepted" | "rejected"
  created_at: string
  updated_at: string
  sender?: Profile
  receiver?: Profile
}

export interface Friendship {
  id: string
  user_id: string
  friend_id: string
  created_at: string
  friend?: Profile
}

export interface BlockedUser {
  id: string
  blocker_id: string
  blocked_id: string
  created_at: string
  blocked?: Profile
}

export interface PostCategory {
  id: string
  name_en: string
  name_jp?: string
  slug: string
  color: string
  created_at: string
}
