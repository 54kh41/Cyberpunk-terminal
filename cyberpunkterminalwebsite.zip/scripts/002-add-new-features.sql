-- =====================================================
-- EXPANDED DATABASE SCHEMA FOR OMEGA CHANNEL
-- Run this AFTER 001-create-tables.sql
-- =====================================================

-- Add new columns to posts table
ALTER TABLE posts ADD COLUMN IF NOT EXISTS category TEXT DEFAULT 'general';
ALTER TABLE posts ADD COLUMN IF NOT EXISTS is_pinned BOOLEAN DEFAULT false;
ALTER TABLE posts ADD COLUMN IF NOT EXISTS video_url TEXT;

-- Add new columns to profiles table
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS avatar_url TEXT;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS bio_en TEXT;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS bio_jp TEXT;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS is_blocked BOOLEAN DEFAULT false;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS blocked_users TEXT[] DEFAULT '{}';

-- Create author_settings table (for site banner, social links, etc.)
CREATE TABLE IF NOT EXISTS author_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  banner_url TEXT,
  avatar_url TEXT,
  display_name_en TEXT,
  display_name_jp TEXT,
  bio_en TEXT,
  bio_jp TEXT,
  facebook_url TEXT,
  instagram_url TEXT,
  tiktok_url TEXT,
  twitter_url TEXT,
  youtube_url TEXT,
  discord_url TEXT,
  royal_road_url TEXT,
  kakuyomu_url TEXT,
  other_links JSONB DEFAULT '[]',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id)
);

-- Create friend_requests table (Variable Connector)
CREATE TABLE IF NOT EXISTS friend_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  sender_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  receiver_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'accepted', 'rejected')),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(sender_id, receiver_id)
);

-- Create friendships table
CREATE TABLE IF NOT EXISTS friendships (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  friend_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, friend_id)
);

-- Create blocked_users table
CREATE TABLE IF NOT EXISTS blocked_users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  blocker_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  blocked_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(blocker_id, blocked_id)
);

-- Create post_categories table
CREATE TABLE IF NOT EXISTS post_categories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name_en TEXT NOT NULL,
  name_jp TEXT,
  slug TEXT UNIQUE NOT NULL,
  color TEXT DEFAULT '#0088FF',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Insert default categories
INSERT INTO post_categories (name_en, name_jp, slug, color) VALUES
  ('Announcement', 'お知らせ', 'announcement', '#FF0000'),
  ('Chapter Update', '章の更新', 'chapter', '#00FF41'),
  ('Character Art', 'キャラクターアート', 'art', '#0088FF'),
  ('Q&A', '質問と回答', 'qa', '#FFD700'),
  ('General', '一般', 'general', '#808080')
ON CONFLICT (slug) DO NOTHING;

-- RLS Policies for new tables

-- Author settings: only admin can read/write their own settings
ALTER TABLE author_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view author settings"
  ON author_settings FOR SELECT
  USING (true);

CREATE POLICY "Only admin can update their settings"
  ON author_settings FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE profiles.id = auth.uid() 
      AND profiles.is_admin = true
    )
  );

-- Friend requests: users can manage their own requests
ALTER TABLE friend_requests ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own friend requests"
  ON friend_requests FOR SELECT
  USING (sender_id = auth.uid() OR receiver_id = auth.uid());

CREATE POLICY "Authenticated users can send friend requests"
  ON friend_requests FOR INSERT
  WITH CHECK (sender_id = auth.uid());

CREATE POLICY "Users can update requests they received"
  ON friend_requests FOR UPDATE
  USING (receiver_id = auth.uid());

-- Friendships: users can view their own friendships
ALTER TABLE friendships ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own friendships"
  ON friendships FOR SELECT
  USING (user_id = auth.uid() OR friend_id = auth.uid());

CREATE POLICY "System can create friendships"
  ON friendships FOR INSERT
  WITH CHECK (user_id = auth.uid() OR friend_id = auth.uid());

-- Blocked users: users can manage their own blocks
ALTER TABLE blocked_users ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own blocks"
  ON blocked_users FOR SELECT
  USING (blocker_id = auth.uid());

CREATE POLICY "Users can block others"
  ON blocked_users FOR INSERT
  WITH CHECK (blocker_id = auth.uid());

CREATE POLICY "Users can unblock others"
  ON blocked_users FOR DELETE
  USING (blocker_id = auth.uid());

-- Post categories: anyone can read
ALTER TABLE post_categories ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view categories"
  ON post_categories FOR SELECT
  USING (true);
