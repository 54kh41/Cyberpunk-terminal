"use client"

import { useEffect, useState } from "react"
import { useLanguage } from "@/lib/language-context"

interface BootMessage {
  text_en: string
  text_jp: string
  delay: number
  isSuccess?: boolean
}

const bootMessages: BootMessage[] = [
  { text_en: "INITIALIZING OMEGA CHANNEL...", text_jp: "オメガチャンネル初期化中...", delay: 0 },
  { text_en: "ESTABLISHING SECURE CONNECTION...", text_jp: "セキュア接続確立中...", delay: 400 },
  {
    text_en: "BYPASSING FIREWALL [████████████] 100%",
    text_jp: "ファイアウォール回避中 [████████████] 100%",
    delay: 800,
  },
  { text_en: "DECRYPTING CLASSIFIED DATA...", text_jp: "機密データ復号中...", delay: 1200 },
  { text_en: "LOADING S.O.U.L. DATABASE...", text_jp: "S.O.U.L.データベース読込中...", delay: 1600 },
  { text_en: "ACCESS GRANTED", text_jp: "アクセス許可", delay: 2000, isSuccess: true },
]

interface BootSequenceProps {
  onComplete: () => void
}

export function BootSequence({ onComplete }: BootSequenceProps) {
  const [visibleLines, setVisibleLines] = useState<number>(0)
  const { language } = useLanguage()

  useEffect(() => {
    bootMessages.forEach((msg, index) => {
      setTimeout(() => {
        setVisibleLines(index + 1)
        if (index === bootMessages.length - 1) {
          setTimeout(onComplete, 800)
        }
      }, msg.delay)
    })
  }, [onComplete])

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#0a0a0a] p-4">
      <div className="terminal-border p-8 max-w-2xl w-full bg-[#0a0a0a]">
        <div className="space-y-2 font-mono text-sm">
          {bootMessages.slice(0, visibleLines).map((msg, index) => (
            <div
              key={index}
              className={`flex items-center gap-2 ${msg.isSuccess ? "text-[#00FF41]" : "text-[#0088FF]"}`}
            >
              <span className="text-[#4a4a4a]">[{String(index + 1).padStart(2, "0")}]</span>
              <span>{language === "jp" ? msg.text_jp : msg.text_en}</span>
              {index === visibleLines - 1 && !msg.isSuccess && <span className="animate-pulse">█</span>}
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
