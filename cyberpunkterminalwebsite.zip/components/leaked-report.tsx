"use client"

export function LeakedReport() {
  return (
    <div className="terminal-border bg-[#0d0d0d] p-6 space-y-6">
      {/* File Header */}
      <div className="border-b border-[#1a1a1a] pb-4 space-y-1 text-xs">
        <div className="flex items-center gap-2">
          <span className="text-[#FF0000]">[ENCRYPTION:</span>
          <span className="text-[#00FF41]">ACTIVE]</span>
        </div>
        <div className="text-[#4a4a4a]">[FILE_TYPE: RAW_INPUT_LOG]</div>
        <div className="text-[#4a4a4a]">
          [SENDER: <span className="text-[#0088FF]">SUZUKI_YUI</span>]
        </div>
        <div className="text-[#4a4a4a]">
          [DATE: <span className="text-[#FF0000]">5_DAYS_POST_INCIDENT</span>]
        </div>
      </div>

      {/* Report Title */}
      <div className="space-y-2">
        <h2 className="text-[#00FF41] text-lg tracking-wider glow-text">
          Yui&apos;s First Report (The &quot;Messy&quot; Draft)
        </h2>
        <div className="text-[#4a4a4a] text-xs">
          Subject: <span className="text-[#0088FF]">Class Y Analysis (First Attempt)</span>
        </div>
      </div>

      {/* Report Content */}
      <div className="space-y-4 text-sm leading-relaxed">
        <p className="text-[#0088FF]">
          I&apos;m sending this because you won&apos;t stop pestering me about &quot;penalties.&quot; Five days
          isn&apos;t enough time to map out an entire class hierarchy, especially with everyone acting so...{" "}
          <span className="text-[#FF0000]">strange</span>.
        </p>

        {/* Leader Section */}
        <div className="terminal-border-green p-4 space-y-2">
          <h3 className="text-[#00FF41] text-xs tracking-widest">▸ LEADER_IDENTIFIED</h3>
          <p className="text-[#0088FF]">
            It&apos;s definitely <span className="text-[#00FF41] font-bold">Keiji Ishida</span>. The person we saw in
            the Student Council. I tried to observe him during lunch, but it&apos;s impossible to get close. His
            classmates don&apos;t just like him; they <span className="text-[#FF0000]">follow</span> him. It&apos;s
            creepy. I watched a girl trip in the hallway, and instead of helping her, everyone looked at Keiji first to
            see if he would help her. When he did, then everyone else started moving. It&apos;s like he&apos;s the
            battery for the whole class.
          </p>
        </div>

        {/* Social Nexus Section */}
        <div className="terminal-border p-4 space-y-2">
          <h3 className="text-[#0088FF] text-xs tracking-widest">▸ THE_SOCIAL_NEXUS</h3>
          <p className="text-[#0088FF]">
            The coordination is <span className="text-[#FF0000]">terrifying</span>. They move in groups, they eat at the
            same time, and they don&apos;t talk to outsiders. It feels like a wall. I tried to talk to one of the girls
            in the library, and she just looked at me like I was a ghost and walked away.
          </p>
        </div>

        {/* The Girl Section */}
        <div className="terminal-border-red p-4 space-y-2">
          <h3 className="text-[#FF0000] text-xs tracking-widest">▸ THE_GIRL (SHIRASAKI)</h3>
          <p className="text-[#0088FF]">
            There&apos;s a girl always with him. <span className="text-[#FF0000] font-bold">Shirasaki</span>. I
            don&apos;t know her first name yet. I can&apos;t tell if she&apos;s his girlfriend or a bodyguard or
            something else. She stays exactly <span className="text-[#00FF41]">three steps behind him</span>. She&apos;s
            the one who looks at everyone like they&apos;re insects. She noticed me watching them once, and I had to
            leave. For a second i thought i was caught, <span className="text-[#4a4a4a]">not that you care</span>.
          </p>
        </div>

        {/* Conclusion */}
        <div className="border-t border-[#1a1a1a] pt-4 space-y-2">
          <h3 className="text-[#4a4a4a] text-xs tracking-widest">▸ CONCLUSION</h3>
          <p className="text-[#0088FF]">
            It&apos;s not just a class. It&apos;s a <span className="text-[#FF0000]">collective</span>. I don&apos;t
            know how you expect me to find a &quot;weakest link&quot; when they don&apos;t even act like individuals.
            This school is a nightmare, <span className="text-[#00FF41]">Ashiro</span>. I&apos;m doing my part, but stop
            sending me 6:00 AM alerts. <span className="text-[#4a4a4a]">I&apos;m tired.</span>
          </p>
        </div>
      </div>

      {/* File Footer */}
      <div className="border-t border-[#1a1a1a] pt-4 flex items-center justify-between text-xs">
        <div className="text-[#4a4a4a]">
          END_OF_FILE // <span className="text-[#FF0000]">CLASSIFIED</span>
        </div>
        <div className="text-[#0088FF]">
          HASH: <span className="text-[#00FF41]">7f3a9b2c...</span>
        </div>
      </div>
    </div>
  )
}
