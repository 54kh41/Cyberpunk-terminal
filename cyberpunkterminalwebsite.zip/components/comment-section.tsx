"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { useLanguage } from "@/lib/language-context"
import type { Comment, Profile } from "@/lib/types"

interface CommentSectionProps {
  postId: string
}

interface TranslatedComment extends Comment {
  translatedContent?: string
  isTranslating?: boolean
}

export function CommentSection({ postId }: CommentSectionProps) {
  const [comments, setComments] = useState<TranslatedComment[]>([])
  const [newComment, setNewComment] = useState("")
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  const [user, setUser] = useState<any>(null)
  const [profile, setProfile] = useState<Profile | null>(null)
  const [blockedUsers, setBlockedUsers] = useState<string[]>([])
  const [showLoginPrompt, setShowLoginPrompt] = useState(false)
  const { language, t } = useLanguage()

  useEffect(() => {
    const supabase = createClient()

    // Check auth status and get profile + blocked users
    supabase.auth.getUser().then(async ({ data }) => {
      setUser(data.user)
      if (data.user) {
        const [profileRes, blockedRes] = await Promise.all([
          supabase.from("profiles").select("*").eq("id", data.user.id).single(),
          supabase.from("blocked_users").select("blocked_id").eq("blocker_id", data.user.id),
        ])
        if (profileRes.data) setProfile(profileRes.data)
        if (blockedRes.data) setBlockedUsers(blockedRes.data.map((b) => b.blocked_id))
      }
    })

    // Fetch comments
    const fetchComments = async () => {
      const { data, error } = await supabase
        .from("comments")
        .select("*, profiles(*)")
        .eq("post_id", postId)
        .order("created_at", { ascending: true })

      if (!error && data) {
        setComments(data)
      }
      setLoading(false)
    }

    fetchComments()

    // Subscribe to new comments
    const channel = supabase
      .channel(`comments-${postId}`)
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "comments", filter: `post_id=eq.${postId}` },
        async (payload) => {
          // Fetch the full comment with profile
          const { data } = await supabase.from("comments").select("*, profiles(*)").eq("id", payload.new.id).single()

          if (data) {
            setComments((prev) => [...prev, data])
          }
        },
      )
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [postId])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!newComment.trim()) return

    if (!user) {
      setShowLoginPrompt(true)
      return
    }

    setSubmitting(true)
    const supabase = createClient()

    const { error } = await supabase.from("comments").insert({
      post_id: postId,
      author_id: user.id,
      content_en: newComment,
    })

    if (!error) {
      setNewComment("")
    }
    setSubmitting(false)
  }

  const handleTranslate = async (commentId: string, originalText: string) => {
    // Mark as translating
    setComments((prev) => prev.map((c) => (c.id === commentId ? { ...c, isTranslating: true } : c)))

    try {
      const targetLang = language === "jp" ? "jp" : "en"
      // Detect if the text is in Japanese (contains Japanese characters)
      const isJapanese = /[\u3040-\u309F\u30A0-\u30FF\u4E00-\u9FAF]/.test(originalText)
      const shouldTranslate = (language === "jp" && !isJapanese) || (language === "en" && isJapanese)

      if (!shouldTranslate) {
        setComments((prev) =>
          prev.map((c) => (c.id === commentId ? { ...c, isTranslating: false, translatedContent: originalText } : c)),
        )
        return
      }

      const response = await fetch("/api/translate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          text: originalText,
          targetLanguage: targetLang,
        }),
      })

      if (response.ok) {
        const { translatedText } = await response.json()
        setComments((prev) =>
          prev.map((c) => (c.id === commentId ? { ...c, isTranslating: false, translatedContent: translatedText } : c)),
        )
      } else {
        setComments((prev) => prev.map((c) => (c.id === commentId ? { ...c, isTranslating: false } : c)))
      }
    } catch (error) {
      setComments((prev) => prev.map((c) => (c.id === commentId ? { ...c, isTranslating: false } : c)))
    }
  }

  const visibleComments = comments.filter((comment) => !blockedUsers.includes(comment.author_id))

  return (
    <div className="border-t border-[#1a1a1a]">
      {/* Comments Header */}
      <div className="p-4 border-b border-[#1a1a1a] bg-[#0d0d0d]">
        <div className="flex items-center gap-2 text-xs">
          <span className="text-[#4a4a4a]">[COMMENTS]</span>
          <span className="text-[#0088FF]">{visibleComments.length}</span>
          {blockedUsers.length > 0 && comments.length !== visibleComments.length && (
            <span className="text-[#4a4a4a] text-xs">
              ({comments.length - visibleComments.length} {t("hidden", "非表示")})
            </span>
          )}
        </div>
      </div>

      {/* Comments List */}
      <div className="max-h-80 overflow-y-auto">
        {loading ? (
          <div className="p-4 text-center text-[#4a4a4a] text-sm">{t("Loading...", "読み込み中...")}</div>
        ) : visibleComments.length === 0 ? (
          <div className="p-4 text-center text-[#4a4a4a] text-sm">
            {t("No comments yet. Be the first!", "コメントはまだありません。最初の一人になりましょう！")}
          </div>
        ) : (
          <div className="divide-y divide-[#1a1a1a]">
            {visibleComments.map((comment) => {
              const displayContent =
                language === "jp" && comment.content_jp
                  ? comment.content_jp
                  : comment.translatedContent || comment.content_en

              return (
                <div key={comment.id} className="p-4">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <span className="text-[#00FF41] text-xs">{comment.profiles?.codename || "ANON"}</span>
                      {comment.profiles?.is_admin && (
                        <span className="text-[#FF0000] text-xs">[{t("AUTHOR", "著者")}]</span>
                      )}
                      <span className="text-[#4a4a4a] text-xs">
                        {new Date(comment.created_at).toLocaleString(language === "jp" ? "ja-JP" : "en-US")}
                      </span>
                    </div>
                    {user && !comment.translatedContent && !comment.isTranslating && (
                      <button
                        onClick={() => handleTranslate(comment.id, comment.content_en)}
                        className="text-[#0088FF] text-xs hover:text-[#00FF41] transition-colors"
                      >
                        [{t("TRANSLATE", "翻訳")}]
                      </button>
                    )}
                  </div>
                  <p className="text-[#c0c0c0] text-sm">
                    {comment.isTranslating ? (
                      <span className="text-[#0088FF] animate-pulse">{t("Translating...", "翻訳中...")}</span>
                    ) : (
                      displayContent
                    )}
                  </p>
                  {comment.translatedContent && comment.translatedContent !== comment.content_en && (
                    <p className="text-[#4a4a4a] text-xs mt-1 italic">
                      {t("Original", "原文")}: {comment.content_en}
                    </p>
                  )}
                </div>
              )
            })}
          </div>
        )}
      </div>

      {/* Comment Input */}
      <div className="p-4 bg-[#0d0d0d]">
        {showLoginPrompt && !user ? (
          <div className="text-center">
            <p className="text-[#FF0000] text-sm mb-2">
              {t("You must login to comment", "コメントするにはログインが必要です")}
            </p>
            <a href="/auth/login" className="text-[#0088FF] text-sm hover:text-[#00FF41] underline">
              {t("Login here", "ログインはこちら")}
            </a>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="flex gap-2">
            <input
              type="text"
              value={newComment}
              onChange={(e) => setNewComment(e.target.value)}
              placeholder={t("Enter your transmission...", "送信内容を入力...")}
              className="flex-1 bg-[#111] border border-[#1a1a1a] text-[#0088FF] text-sm p-2 focus:border-[#0088FF] focus:outline-none placeholder-[#4a4a4a]"
            />
            <button
              type="submit"
              disabled={submitting || !newComment.trim()}
              className="px-4 py-2 bg-[#0088FF] text-[#0a0a0a] text-xs tracking-wider font-bold hover:bg-[#00FF41] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {submitting ? "..." : t("SEND", "送信")}
            </button>
          </form>
        )}
      </div>
    </div>
  )
}
