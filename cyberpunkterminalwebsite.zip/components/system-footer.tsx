"use client"

import { useEffect, useState } from "react"
import { useLanguage } from "@/lib/language-context"

export function SystemFooter() {
  const [time, setTime] = useState("")
  const { t } = useLanguage()

  useEffect(() => {
    const updateTime = () => {
      const now = new Date()
      setTime(now.toISOString().replace("T", " ").slice(0, 19))
    }
    updateTime()
    const interval = setInterval(updateTime, 1000)
    return () => clearInterval(interval)
  }, [])

  return (
    <footer className="fixed bottom-0 left-0 right-0 terminal-border-green bg-[#0a0a0a]/95 backdrop-blur-sm p-3 z-50">
      <div className="max-w-7xl mx-auto flex items-center justify-between text-xs">
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2">
            <span className="text-[#4a4a4a]">{t("ACTIVE_VARIABLES", "アクティブ変数")}:</span>
            <span className="text-[#FF0000] font-bold">90</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-[#4a4a4a]">{t("STATUS", "状態")}:</span>
            <span className="text-[#00FF41]">{t("OBSERVATION_MODE", "観測モード")}</span>
          </div>
        </div>

        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2">
            <span className="text-[#4a4a4a]">{t("ENCRYPTION", "暗号化")}:</span>
            <span className="text-[#0088FF]">AES-256</span>
          </div>
          <div className="text-[#4a4a4a]">
            UTC: <span className="text-[#0088FF]">{time}</span>
          </div>
        </div>
      </div>
    </footer>
  )
}
