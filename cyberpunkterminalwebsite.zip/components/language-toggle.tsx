"use client"

import { useLanguage } from "@/lib/language-context"

export function LanguageToggle() {
  const { language, setLanguage } = useLanguage()

  return (
    <div className="fixed top-4 right-4 z-50">
      <div className="terminal-border bg-[#0a0a0a]/95 backdrop-blur-sm p-2">
        <div className="flex items-center gap-1">
          <button
            onClick={() => setLanguage("en")}
            className={`px-3 py-1 text-xs tracking-wider transition-all ${
              language === "en" ? "bg-[#0088FF] text-[#0a0a0a] font-bold" : "text-[#4a4a4a] hover:text-[#0088FF]"
            }`}
          >
            EN
          </button>
          <span className="text-[#4a4a4a]">/</span>
          <button
            onClick={() => setLanguage("jp")}
            className={`px-3 py-1 text-xs tracking-wider transition-all ${
              language === "jp" ? "bg-[#00FF41] text-[#0a0a0a] font-bold" : "text-[#4a4a4a] hover:text-[#00FF41]"
            }`}
          >
            JP
          </button>
        </div>
      </div>
    </div>
  )
}
