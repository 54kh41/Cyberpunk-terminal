"use client"

import type React from "react"

import { useState, useRef } from "react"
import { useLanguage } from "@/lib/language-context"

interface FileUploadProps {
  onUpload: (url: string, isVideo: boolean) => void
  uploadType?: string
  accept?: string
  maxSizeMB?: number
}

export function FileUpload({
  onUpload,
  uploadType = "general",
  accept = "image/*,video/*",
  maxSizeMB = 10,
}: FileUploadProps) {
  const [uploading, setUploading] = useState(false)
  const [progress, setProgress] = useState(0)
  const [error, setError] = useState<string | null>(null)
  const inputRef = useRef<HTMLInputElement>(null)
  const { t } = useLanguage()

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    setError(null)
    setUploading(true)
    setProgress(10)

    try {
      const formData = new FormData()
      formData.append("file", file)
      formData.append("type", uploadType)

      setProgress(30)

      const response = await fetch("/api/upload", {
        method: "POST",
        body: formData,
      })

      setProgress(80)

      if (!response.ok) {
        const data = await response.json()
        throw new Error(data.error || "Upload failed")
      }

      const data = await response.json()
      setProgress(100)
      onUpload(data.url, data.isVideo)
    } catch (err: any) {
      setError(err.message || "Upload failed")
    } finally {
      setUploading(false)
      setProgress(0)
      if (inputRef.current) inputRef.current.value = ""
    }
  }

  return (
    <div className="space-y-2">
      <div className="relative">
        <input
          ref={inputRef}
          type="file"
          accept={accept}
          onChange={handleFileSelect}
          disabled={uploading}
          className="hidden"
          id={`file-upload-${uploadType}`}
        />
        <label
          htmlFor={`file-upload-${uploadType}`}
          className={`
            inline-flex items-center gap-2 cursor-pointer
            terminal-border bg-[#0a0a0a] px-4 py-2 text-[#0088FF] text-xs tracking-wider
            hover:bg-[#0088FF] hover:text-[#0a0a0a] transition-all
            ${uploading ? "opacity-50 cursor-not-allowed" : ""}
          `}
        >
          {uploading ? (
            <>
              <span className="animate-pulse">◈</span>
              {t("UPLOADING...", "アップロード中...")} {progress}%
            </>
          ) : (
            <>
              <span>◈</span>
              {t("[UPLOAD FILE]", "[ファイルをアップロード]")}
            </>
          )}
        </label>
      </div>

      {uploading && (
        <div className="h-1 bg-[#1a1a1a] rounded overflow-hidden">
          <div className="h-full bg-[#00FF41] transition-all duration-300" style={{ width: `${progress}%` }} />
        </div>
      )}

      {error && (
        <p className="text-[#FF0000] text-xs">
          {t("ERROR", "エラー")}: {error}
        </p>
      )}
    </div>
  )
}
