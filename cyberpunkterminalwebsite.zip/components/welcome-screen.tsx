"use client"

import { useState, useEffect } from "react"

interface WelcomeScreenProps {
  onComplete: () => void
}

export function WelcomeScreen({ onComplete }: WelcomeScreenProps) {
  const [phase, setPhase] = useState<"title" | "subtitle" | "ready">("title")
  const [glitchActive, setGlitchActive] = useState(false)

  useEffect(() => {
    // Glitch effect
    const glitchInterval = setInterval(() => {
      setGlitchActive(true)
      setTimeout(() => setGlitchActive(false), 100)
    }, 3000)

    // Phase transitions
    const subtitleTimer = setTimeout(() => setPhase("subtitle"), 1500)
    const readyTimer = setTimeout(() => setPhase("ready"), 3000)

    return () => {
      clearInterval(glitchInterval)
      clearTimeout(subtitleTimer)
      clearTimeout(readyTimer)
    }
  }, [])

  return (
    <div
      className="min-h-screen flex flex-col items-center justify-center bg-[#0a0a0a] p-4 cursor-pointer"
      onClick={phase === "ready" ? onComplete : undefined}
    >
      <div className="text-center max-w-4xl">
        {/* Decorative top line */}
        <div className="flex items-center justify-center gap-4 mb-8 opacity-50">
          <div className="h-px w-16 bg-gradient-to-r from-transparent to-[#0088FF]" />
          <span className="text-[#4a4a4a] text-xs tracking-[0.5em]">WELCOME</span>
          <div className="h-px w-16 bg-gradient-to-l from-transparent to-[#0088FF]" />
        </div>

        {/* Japanese Title */}
        <div
          className={`mb-4 transition-all duration-500 ${
            phase !== "title" ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
          }`}
        >
          <p className="text-[#00FF41] text-lg md:text-xl tracking-widest mb-2">ようこそ</p>
          <h2
            className={`text-[#0088FF] text-2xl md:text-4xl tracking-wider font-bold ${
              glitchActive ? "animate-pulse" : ""
            }`}
            style={{
              textShadow: glitchActive ? "2px 0 #FF0000, -2px 0 #00FF41" : "0 0 10px rgba(0, 136, 255, 0.5)",
            }}
          >
            『砕かれた魂の微積分』の世界へ
          </h2>
        </div>

        {/* Divider */}
        <div className="flex items-center justify-center gap-4 my-6">
          <div className="h-px flex-1 max-w-32 bg-gradient-to-r from-transparent to-[#0088FF]" />
          <span className="text-[#FF0000] text-xl animate-pulse">◆</span>
          <div className="h-px flex-1 max-w-32 bg-gradient-to-l from-transparent to-[#0088FF]" />
        </div>

        {/* English Title */}
        <div className="mb-8">
          <p className="text-[#4a4a4a] text-sm tracking-[0.3em] mb-3">TO THE WORLD OF</p>
          <h1
            className={`text-[#00FF41] text-3xl md:text-5xl lg:text-6xl tracking-wider font-bold glow-text ${
              glitchActive ? "" : ""
            }`}
            style={{
              textShadow: "0 0 20px rgba(0, 255, 65, 0.5), 0 0 40px rgba(0, 255, 65, 0.3)",
            }}
          >
            THE CALCULUS OF
          </h1>
          <h1
            className="text-[#00FF41] text-3xl md:text-5xl lg:text-6xl tracking-wider font-bold glow-text mt-2"
            style={{
              textShadow: "0 0 20px rgba(0, 255, 65, 0.5), 0 0 40px rgba(0, 255, 65, 0.3)",
            }}
          >
            A SHATTERED SOUL
          </h1>
        </div>

        {/* Subtitle */}
        <div
          className={`transition-all duration-700 ${
            phase === "subtitle" || phase === "ready" ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
          }`}
        >
          <p className="text-[#4a4a4a] text-sm tracking-widest mb-2">A PSYCHOLOGICAL THRILLER LIGHT NOVEL</p>
          <p className="text-[#0088FF] text-xs tracking-wider">CYBER-NOIR // MIND GAMES // CALCULATED CHAOS</p>
        </div>

        {/* Enter prompt */}
        <div className={`mt-12 transition-all duration-500 ${phase === "ready" ? "opacity-100" : "opacity-0"}`}>
          <div className="terminal-border inline-block px-8 py-3 hover:border-[#00FF41] transition-colors cursor-pointer group">
            <span className="text-[#0088FF] group-hover:text-[#00FF41] text-sm tracking-widest flex items-center gap-3">
              <span className="text-[#FF0000] animate-pulse">▶</span>
              CLICK TO ENTER
              <span className="text-[#4a4a4a]">//</span>
              クリックして入場
            </span>
          </div>
          <p className="text-[#4a4a4a] text-xs mt-4 animate-pulse">[ PRESS ANYWHERE TO CONTINUE ]</p>
        </div>

        {/* Decorative bottom */}
        <div className="flex items-center justify-center gap-4 mt-12 opacity-30">
          <span className="text-[#4a4a4a] text-xs">OMEGA_CHANNEL</span>
          <span className="text-[#FF0000]">■</span>
          <span className="text-[#4a4a4a] text-xs">v2.7.1</span>
        </div>
      </div>
    </div>
  )
}
