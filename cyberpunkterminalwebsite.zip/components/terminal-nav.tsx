"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { useLanguage } from "@/lib/language-context"
import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"

const navItems = [
  { href: "/", label_en: "FEED", label_jp: "フィード", code: "0x001" },
  { href: "/archives", label_en: "ARCHIVES", label_jp: "アーカイブ", code: "0x002" },
  { href: "/mesh-net", label_en: "MESH-NET", label_jp: "メッシュネット", code: "0x003" },
  { href: "/friends", label_en: "CONNECTOR", label_jp: "コネクタ", code: "0x004" },
  { href: "/author", label_en: "AUTHOR", label_jp: "著者", code: "0x005" },
]

export function TerminalNav() {
  const pathname = usePathname()
  const { language } = useLanguage()
  const [user, setUser] = useState<any>(null)
  const [isAdmin, setIsAdmin] = useState(false)

  useEffect(() => {
    const supabase = createClient()

    supabase.auth.getUser().then(async ({ data }) => {
      setUser(data.user)
      if (data.user) {
        const { data: profile } = await supabase.from("profiles").select("is_admin").eq("id", data.user.id).single()
        setIsAdmin(profile?.is_admin || false)
      }
    })
  }, [])

  const handleLogout = async () => {
    const supabase = createClient()
    await supabase.auth.signOut()
    setUser(null)
    setIsAdmin(false)
    window.location.href = "/"
  }

  return (
    <nav className="terminal-border bg-[#0a0a0a]/90 backdrop-blur-sm p-4 mb-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div className="flex items-center gap-2">
          <span className="text-[#FF0000]">▓</span>
          <span className="text-[#00FF41] text-sm tracking-widest">OMEGA_CHANNEL</span>
          <span className="text-[#4a4a4a] text-xs">v2.7.1</span>
        </div>

        <div className="flex items-center gap-4 md:gap-6 flex-wrap">
          {navItems.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className={`group flex items-center gap-2 text-xs tracking-wider transition-all duration-300 ${
                pathname === item.href ? "text-[#00FF41] glow-text" : "text-[#0088FF] hover:text-[#00FF41]"
              }`}
            >
              <span className="text-[#4a4a4a] group-hover:text-[#0088FF] hidden md:inline">[{item.code}]</span>
              <span>{language === "jp" ? item.label_jp : item.label_en}</span>
            </Link>
          ))}
          {isAdmin && (
            <Link
              href="/admin"
              className={`group flex items-center gap-2 text-xs tracking-wider transition-all duration-300 ${
                pathname.startsWith("/admin") ? "text-[#FF0000] glow-text" : "text-[#FF0000] hover:text-[#00FF41]"
              }`}
            >
              <span className="text-[#4a4a4a] group-hover:text-[#FF0000] hidden md:inline">[0xADM]</span>
              <span>{language === "jp" ? "管理" : "ADMIN"}</span>
            </Link>
          )}
        </div>

        <div className="flex items-center gap-4 text-xs">
          {user ? (
            <button onClick={handleLogout} className="text-[#FF0000] hover:text-[#00FF41] transition-colors">
              [{language === "jp" ? "ログアウト" : "LOGOUT"}]
            </button>
          ) : (
            <Link href="/auth/login" className="text-[#0088FF] hover:text-[#00FF41] transition-colors">
              [{language === "jp" ? "ログイン" : "LOGIN"}]
            </Link>
          )}
        </div>
      </div>
    </nav>
  )
}
