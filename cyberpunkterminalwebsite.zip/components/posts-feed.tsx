"use client"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { useLanguage } from "@/lib/language-context"
import type { Post } from "@/lib/types"
import { CommentSection } from "./comment-section"

export function PostsFeed() {
  const [posts, setPosts] = useState<Post[]>([])
  const [loading, setLoading] = useState(true)
  const { language, t } = useLanguage()

  useEffect(() => {
    const fetchPosts = async () => {
      const supabase = createClient()
      const { data, error } = await supabase
        .from("posts")
        .select("*, profiles(*)")
        .order("created_at", { ascending: false })

      if (!error && data) {
        setPosts(data)
      }
      setLoading(false)
    }

    fetchPosts()
  }, [])

  if (loading) {
    return (
      <div className="terminal-border bg-[#0a0a0a] p-8 text-center">
        <span className="text-[#0088FF] animate-pulse">{t("LOADING TRANSMISSIONS...", "送信を読み込み中...")}</span>
      </div>
    )
  }

  if (posts.length === 0) {
    return (
      <div className="terminal-border bg-[#0a0a0a] p-8">
        <div className="text-center space-y-4">
          <div className="text-[#4a4a4a] text-6xl">◇</div>
          <h3 className="text-[#0088FF] text-lg tracking-widest">
            {t("NO TRANSMISSIONS YET", "まだ送信はありません")}
          </h3>
          <p className="text-[#4a4a4a] text-sm">
            {t("The author has not posted any updates.", "著者はまだ更新を投稿していません。")}
          </p>
          <div className="text-[#00FF41] text-xs mt-4">{t("// STANDBY FOR INCOMING DATA", "// データ受信待機中")}</div>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {posts.map((post) => (
        <article key={post.id} className="terminal-border bg-[#0a0a0a] overflow-hidden">
          {/* Post Header */}
          <div className="border-b border-[#1a1a1a] p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span className="text-[#FF0000]">▓</span>
                <span className="text-[#00FF41] text-sm tracking-wider">{post.profiles?.codename || "ADMIN"}</span>
                <span className="text-[#4a4a4a] text-xs">[{t("AUTHOR", "著者")}]</span>
              </div>
              <span className="text-[#4a4a4a] text-xs">
                {new Date(post.created_at).toLocaleDateString(language === "jp" ? "ja-JP" : "en-US")}
              </span>
            </div>
          </div>

          {/* Post Content */}
          <div className="p-6">
            <h2 className="text-[#0088FF] text-xl md:text-2xl tracking-wider mb-4 glow-text">
              {language === "jp" && post.title_jp ? post.title_jp : post.title_en}
            </h2>

            {post.image_url && (
              <div className="mb-4 terminal-border-green p-2">
                <img src={post.image_url || "/placeholder.svg"} alt={post.title_en} className="w-full h-auto" />
              </div>
            )}

            <div className="text-[#c0c0c0] text-sm leading-relaxed whitespace-pre-wrap">
              {language === "jp" && post.content_jp ? post.content_jp : post.content_en}
            </div>
          </div>

          {/* Comments Section */}
          <CommentSection postId={post.id} />
        </article>
      ))}
    </div>
  )
}
