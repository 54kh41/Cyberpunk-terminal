"use client"
import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { useRouter } from "next/navigation"
import { TerminalNav } from "@/components/terminal-nav"
import { SystemFooter } from "@/components/system-footer"
import { LanguageToggle } from "@/components/language-toggle"
import { useLanguage } from "@/lib/language-context"
import type { Profile, FriendRequest, Friendship } from "@/lib/types"

export default function FriendsPage() {
  const [user, setUser] = useState<any>(null)
  const [profile, setProfile] = useState<Profile | null>(null)
  const [loading, setLoading] = useState(true)
  const [friendRequests, setFriendRequests] = useState<FriendRequest[]>([])
  const [friendships, setFriendships] = useState<Friendship[]>([])
  const [blockedUsers, setBlockedUsers] = useState<{ id: string; blocked_id: string; blocked?: Profile }[]>([])
  const [allUsers, setAllUsers] = useState<Profile[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const [activeTab, setActiveTab] = useState<"friends" | "requests" | "search" | "blocked">("friends")
  const router = useRouter()
  const { t } = useLanguage()

  useEffect(() => {
    const init = async () => {
      const supabase = createClient()
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        router.push("/auth/login")
        return
      }

      setUser(user)

      // Fetch profile
      const { data: profileData } = await supabase.from("profiles").select("*").eq("id", user.id).single()

      if (profileData) setProfile(profileData)

      // Fetch friend requests
      const { data: requests } = await supabase
        .from("friend_requests")
        .select(
          "*, sender:profiles!friend_requests_sender_id_fkey(*), receiver:profiles!friend_requests_receiver_id_fkey(*)",
        )
        .or(`sender_id.eq.${user.id},receiver_id.eq.${user.id}`)
        .eq("status", "pending")

      if (requests) setFriendRequests(requests)

      // Fetch friendships
      const { data: friends } = await supabase
        .from("friendships")
        .select("*, friend:profiles!friendships_friend_id_fkey(*)")
        .eq("user_id", user.id)

      if (friends) setFriendships(friends)

      const { data: blocked } = await supabase
        .from("blocked_users")
        .select("*, blocked:profiles!blocked_users_blocked_id_fkey(*)")
        .eq("blocker_id", user.id)

      if (blocked) setBlockedUsers(blocked)

      setLoading(false)
    }

    init()
  }, [router])

  const handleSearch = async () => {
    if (!searchQuery.trim()) return

    const supabase = createClient()
    const { data } = await supabase
      .from("profiles")
      .select("*")
      .ilike("codename", `%${searchQuery}%`)
      .neq("id", user.id)
      .limit(20)

    if (data) setAllUsers(data)
  }

  const handleSendRequest = async (receiverId: string) => {
    const supabase = createClient()
    const { data, error } = await supabase
      .from("friend_requests")
      .insert({ sender_id: user.id, receiver_id: receiverId })
      .select(
        "*, sender:profiles!friend_requests_sender_id_fkey(*), receiver:profiles!friend_requests_receiver_id_fkey(*)",
      )
      .single()

    if (!error && data) {
      setFriendRequests([...friendRequests, data])
    }
  }

  const handleAcceptRequest = async (requestId: string, senderId: string) => {
    const supabase = createClient()

    // Update request status
    await supabase.from("friend_requests").update({ status: "accepted" }).eq("id", requestId)

    // Create bidirectional friendship
    await supabase.from("friendships").insert([
      { user_id: user.id, friend_id: senderId },
      { user_id: senderId, friend_id: user.id },
    ])

    // Refresh data
    const { data: friends } = await supabase
      .from("friendships")
      .select("*, friend:profiles!friendships_friend_id_fkey(*)")
      .eq("user_id", user.id)

    if (friends) setFriendships(friends)
    setFriendRequests(friendRequests.filter((r) => r.id !== requestId))
  }

  const handleRejectRequest = async (requestId: string) => {
    const supabase = createClient()
    await supabase.from("friend_requests").update({ status: "rejected" }).eq("id", requestId)
    setFriendRequests(friendRequests.filter((r) => r.id !== requestId))
  }

  const handleRemoveFriend = async (friendshipId: string, friendId: string) => {
    const supabase = createClient()

    // Remove bidirectional friendship
    await supabase.from("friendships").delete().eq("id", friendshipId)
    await supabase.from("friendships").delete().eq("user_id", friendId).eq("friend_id", user.id)

    setFriendships(friendships.filter((f) => f.id !== friendshipId))
  }

  const handleBlockUser = async (userId: string) => {
    const supabase = createClient()
    const { data, error } = await supabase
      .from("blocked_users")
      .insert({ blocker_id: user.id, blocked_id: userId })
      .select("*, blocked:profiles!blocked_users_blocked_id_fkey(*)")
      .single()

    if (!error && data) {
      setBlockedUsers([...blockedUsers, data])
      // Also remove friendship if exists
      const existingFriendship = friendships.find((f) => f.friend_id === userId)
      if (existingFriendship) {
        await handleRemoveFriend(existingFriendship.id, userId)
      }
    }
  }

  const handleUnblockUser = async (blockedRecordId: string) => {
    const supabase = createClient()
    const { error } = await supabase.from("blocked_users").delete().eq("id", blockedRecordId)

    if (!error) {
      setBlockedUsers(blockedUsers.filter((b) => b.id !== blockedRecordId))
    }
  }

  const isBlocked = (userId: string) => blockedUsers.some((b) => b.blocked_id === userId)

  if (loading) {
    return (
      <main className="min-h-screen flex items-center justify-center">
        <span className="text-[#0088FF] animate-pulse">{t("LOADING...", "読み込み中...")}</span>
      </main>
    )
  }

  const pendingReceived = friendRequests.filter((r) => r.receiver_id === user?.id)
  const pendingSent = friendRequests.filter((r) => r.sender_id === user?.id)

  return (
    <main className="min-h-screen pb-20">
      <LanguageToggle />
      <div className="max-w-5xl mx-auto p-4 md:p-6">
        <TerminalNav />

        {/* Header */}
        <div className="terminal-border-green bg-[#0a0a0a] p-4 mb-6">
          <h1 className="text-[#00FF41] text-xl md:text-2xl tracking-widest glow-text">
            // {t("VARIABLE_CONNECTOR", "変数コネクタ")}
          </h1>
          <p className="text-[#4a4a4a] text-xs">
            {t("Connect with other readers", "他の読者とつながる")} // {t("FRIEND SYSTEM", "フレンドシステム")}
          </p>
        </div>

        {/* Tabs - Added blocked tab */}
        <div className="flex gap-2 mb-6 flex-wrap">
          {(["friends", "requests", "search", "blocked"] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`terminal-border px-4 py-2 text-xs tracking-wider transition-all ${
                activeTab === tab
                  ? tab === "blocked"
                    ? "bg-[#FF0000] text-[#0a0a0a]"
                    : "bg-[#00FF41] text-[#0a0a0a]"
                  : tab === "blocked"
                    ? "bg-[#0a0a0a] text-[#FF0000] hover:bg-[#111]"
                    : "bg-[#0a0a0a] text-[#00FF41] hover:bg-[#111]"
              }`}
            >
              [
              {t(
                tab === "friends"
                  ? "FRIENDS"
                  : tab === "requests"
                    ? "REQUESTS"
                    : tab === "search"
                      ? "SEARCH"
                      : "BLOCKED",
                tab === "friends"
                  ? "フレンド"
                  : tab === "requests"
                    ? "リクエスト"
                    : tab === "search"
                      ? "検索"
                      : "ブロック",
              )}
              ]
              {tab === "requests" && pendingReceived.length > 0 && (
                <span className="ml-2 text-[#FF0000]">({pendingReceived.length})</span>
              )}
              {tab === "blocked" && blockedUsers.length > 0 && <span className="ml-2">({blockedUsers.length})</span>}
            </button>
          ))}
        </div>

        {/* Friends Tab */}
        {activeTab === "friends" && (
          <div className="space-y-4">
            <h2 className="text-[#0088FF] text-lg tracking-wider">
              {t("CONNECTED VARIABLES", "接続された変数")} ({friendships.length})
            </h2>
            {friendships.length === 0 ? (
              <div className="terminal-border bg-[#0d0d0d] p-8 text-center">
                <p className="text-[#4a4a4a]">
                  {t(
                    "No friends yet. Search for users to connect!",
                    "まだフレンドがいません。ユーザーを検索して接続しましょう！",
                  )}
                </p>
              </div>
            ) : (
              friendships.map((friendship) => (
                <div key={friendship.id} className="terminal-border bg-[#0d0d0d] p-4 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <span className="text-[#00FF41]">*</span>
                    <span className="text-[#00FF41] tracking-wider">{friendship.friend?.codename}</span>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => handleBlockUser(friendship.friend_id)}
                      className="text-[#FF0000] text-xs hover:underline"
                    >
                      [{t("BLOCK", "ブロック")}]
                    </button>
                    <button
                      onClick={() => handleRemoveFriend(friendship.id, friendship.friend_id)}
                      className="text-[#4a4a4a] text-xs hover:underline hover:text-[#FF0000]"
                    >
                      [{t("DISCONNECT", "切断")}]
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        {/* Requests Tab */}
        {activeTab === "requests" && (
          <div className="space-y-6">
            {/* Received Requests */}
            <div className="space-y-4">
              <h2 className="text-[#0088FF] text-lg tracking-wider">
                {t("INCOMING REQUESTS", "受信リクエスト")} ({pendingReceived.length})
              </h2>
              {pendingReceived.length === 0 ? (
                <div className="terminal-border bg-[#0d0d0d] p-4 text-center">
                  <p className="text-[#4a4a4a] text-sm">{t("No pending requests", "保留中のリクエストはありません")}</p>
                </div>
              ) : (
                pendingReceived.map((request) => (
                  <div
                    key={request.id}
                    className="terminal-border-green bg-[#0d0d0d] p-4 flex items-center justify-between flex-wrap gap-4"
                  >
                    <div className="flex items-center gap-3">
                      <span className="text-[#00FF41]">*</span>
                      <span className="text-[#00FF41] tracking-wider">{request.sender?.codename}</span>
                      <span className="text-[#4a4a4a] text-xs">{t("wants to connect", "が接続を希望")}</span>
                    </div>
                    <div className="flex gap-2">
                      <button
                        onClick={() => handleAcceptRequest(request.id, request.sender_id)}
                        className="terminal-border-green bg-[#0a0a0a] px-4 py-2 text-[#00FF41] text-xs hover:bg-[#00FF41] hover:text-[#0a0a0a] transition-all"
                      >
                        [{t("ACCEPT", "承認")}]
                      </button>
                      <button
                        onClick={() => handleRejectRequest(request.id)}
                        className="terminal-border-red bg-[#0a0a0a] px-4 py-2 text-[#FF0000] text-xs hover:bg-[#FF0000] hover:text-[#0a0a0a] transition-all"
                      >
                        [{t("REJECT", "拒否")}]
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Sent Requests */}
            <div className="space-y-4">
              <h2 className="text-[#0088FF] text-lg tracking-wider">
                {t("SENT REQUESTS", "送信リクエスト")} ({pendingSent.length})
              </h2>
              {pendingSent.length === 0 ? (
                <div className="terminal-border bg-[#0d0d0d] p-4 text-center">
                  <p className="text-[#4a4a4a] text-sm">{t("No pending requests", "保留中のリクエストはありません")}</p>
                </div>
              ) : (
                pendingSent.map((request) => (
                  <div key={request.id} className="terminal-border bg-[#0d0d0d] p-4 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <span className="text-[#0088FF]">*</span>
                      <span className="text-[#0088FF] tracking-wider">{request.receiver?.codename}</span>
                      <span className="text-[#4a4a4a] text-xs">{t("pending...", "保留中...")}</span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* Search Tab */}
        {activeTab === "search" && (
          <div className="space-y-6">
            <div className="terminal-border bg-[#0d0d0d] p-4">
              <div className="flex gap-4">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleSearch()}
                  placeholder={t("Enter codename...", "コードネームを入力...")}
                  className="flex-1 bg-[#111] border border-[#1a1a1a] text-[#0088FF] p-3 focus:border-[#0088FF] focus:outline-none"
                />
                <button
                  onClick={handleSearch}
                  className="terminal-border-green bg-[#0a0a0a] px-6 py-2 text-[#00FF41] text-sm hover:bg-[#00FF41] hover:text-[#0a0a0a] transition-all"
                >
                  [{t("SEARCH", "検索")}]
                </button>
              </div>
            </div>

            {allUsers.length > 0 && (
              <div className="space-y-4">
                <h2 className="text-[#0088FF] text-lg tracking-wider">
                  {t("SEARCH RESULTS", "検索結果")} ({allUsers.length})
                </h2>
                {allUsers.map((userProfile) => {
                  const isFriend = friendships.some((f) => f.friend_id === userProfile.id)
                  const hasPendingRequest = friendRequests.some(
                    (r) =>
                      (r.sender_id === user.id && r.receiver_id === userProfile.id) ||
                      (r.receiver_id === user.id && r.sender_id === userProfile.id),
                  )
                  const userIsBlocked = isBlocked(userProfile.id)

                  return (
                    <div
                      key={userProfile.id}
                      className={`terminal-border bg-[#0d0d0d] p-4 flex items-center justify-between ${userIsBlocked ? "opacity-50" : ""}`}
                    >
                      <div className="flex items-center gap-3">
                        <span className="text-[#00FF41]">*</span>
                        <span className="text-[#00FF41] tracking-wider">{userProfile.codename}</span>
                        {userProfile.is_admin && (
                          <span className="text-[#FF0000] text-xs">[{t("AUTHOR", "著者")}]</span>
                        )}
                        {userIsBlocked && (
                          <span className="text-[#FF0000] text-xs">[{t("BLOCKED", "ブロック中")}]</span>
                        )}
                      </div>
                      {userIsBlocked ? (
                        <button
                          onClick={() => {
                            const record = blockedUsers.find((b) => b.blocked_id === userProfile.id)
                            if (record) handleUnblockUser(record.id)
                          }}
                          className="text-[#00FF41] text-xs hover:underline"
                        >
                          [{t("UNBLOCK", "解除")}]
                        </button>
                      ) : isFriend ? (
                        <span className="text-[#00FF41] text-xs">{t("CONNECTED", "接続済")}</span>
                      ) : hasPendingRequest ? (
                        <span className="text-[#4a4a4a] text-xs">{t("PENDING", "保留中")}</span>
                      ) : (
                        <button
                          onClick={() => handleSendRequest(userProfile.id)}
                          className="terminal-border-green bg-[#0a0a0a] px-4 py-2 text-[#00FF41] text-xs hover:bg-[#00FF41] hover:text-[#0a0a0a] transition-all"
                        >
                          [{t("CONNECT", "接続")}]
                        </button>
                      )}
                    </div>
                  )
                })}
              </div>
            )}
          </div>
        )}

        {activeTab === "blocked" && (
          <div className="space-y-4">
            <h2 className="text-[#FF0000] text-lg tracking-wider">
              {t("BLOCKED USERS", "ブロック中のユーザー")} ({blockedUsers.length})
            </h2>
            {blockedUsers.length === 0 ? (
              <div className="terminal-border bg-[#0d0d0d] p-8 text-center">
                <p className="text-[#4a4a4a]">{t("No blocked users", "ブロックしているユーザーはいません")}</p>
              </div>
            ) : (
              blockedUsers.map((blocked) => (
                <div
                  key={blocked.id}
                  className="terminal-border-red bg-[#0d0d0d] p-4 flex items-center justify-between"
                >
                  <div className="flex items-center gap-3">
                    <span className="text-[#FF0000]">X</span>
                    <span className="text-[#4a4a4a] tracking-wider">{blocked.blocked?.codename}</span>
                  </div>
                  <button
                    onClick={() => handleUnblockUser(blocked.id)}
                    className="terminal-border-green bg-[#0a0a0a] px-4 py-2 text-[#00FF41] text-xs hover:bg-[#00FF41] hover:text-[#0a0a0a] transition-all"
                  >
                    [{t("UNBLOCK", "解除")}]
                  </button>
                </div>
              ))
            )}

            <div className="terminal-border bg-[#0a0a0a] p-4 mt-6">
              <p className="text-[#4a4a4a] text-xs">
                {t(
                  "Blocked users cannot see your comments and chat messages. You will not see their content either.",
                  "ブロックしたユーザーはあなたのコメントやチャットメッセージを見ることができません。あなたも彼らのコンテンツを見ることはできません。",
                )}
              </p>
            </div>
          </div>
        )}
      </div>

      <SystemFooter />
    </main>
  )
}
