"use client"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { useRouter } from "next/navigation"
import { TerminalNav } from "@/components/terminal-nav"
import { SystemFooter } from "@/components/system-footer"
import { LanguageToggle } from "@/components/language-toggle"
import { useLanguage } from "@/lib/language-context"
import type { ChatMessage } from "@/lib/types"

export default function AdminChatPage() {
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [loading, setLoading] = useState(true)
  const [deleting, setDeleting] = useState<string | null>(null)
  const router = useRouter()
  const { t, language } = useLanguage()

  useEffect(() => {
    const init = async () => {
      const supabase = createClient()
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        router.push("/auth/login")
        return
      }

      const { data: profile } = await supabase.from("profiles").select("is_admin").eq("id", user.id).single()

      if (!profile?.is_admin) {
        router.push("/")
        return
      }

      const { data } = await supabase
        .from("chat_messages")
        .select("*, profiles(*)")
        .order("created_at", { ascending: false })
        .limit(200)

      if (data) setMessages(data)
      setLoading(false)
    }

    init()
  }, [router])

  const handleDelete = async (messageId: string) => {
    setDeleting(messageId)
    const supabase = createClient()
    const { error } = await supabase.from("chat_messages").delete().eq("id", messageId)

    if (!error) {
      setMessages(messages.filter((m) => m.id !== messageId))
    }
    setDeleting(null)
  }

  const handleClearAll = async () => {
    if (
      !confirm(
        t(
          "Are you sure you want to delete all chat messages?",
          "すべてのチャットメッセージを削除してもよろしいですか？",
        ),
      )
    ) {
      return
    }

    const supabase = createClient()
    const { error } = await supabase.from("chat_messages").delete().neq("id", "00000000-0000-0000-0000-000000000000")

    if (!error) {
      setMessages([])
    }
  }

  if (loading) {
    return (
      <main className="min-h-screen flex items-center justify-center">
        <span className="text-[#0088FF] animate-pulse">{t("LOADING...", "読み込み中...")}</span>
      </main>
    )
  }

  return (
    <main className="min-h-screen pb-20">
      <LanguageToggle />
      <div className="max-w-5xl mx-auto p-4 md:p-6">
        <TerminalNav />

        <div className="terminal-border-red bg-[#0a0a0a] p-4 mb-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-[#FF0000] text-xl tracking-widest glow-text">
                // {t("CHAT HISTORY", "チャット履歴")}
              </h1>
              <p className="text-[#4a4a4a] text-xs mt-1">
                {t("View and moderate chat messages", "チャットメッセージの確認と管理")}
              </p>
            </div>
            <a href="/admin" className="text-[#0088FF] text-xs hover:text-[#00FF41]">
              [{t("BACK", "戻る")}]
            </a>
          </div>
        </div>

        {/* Stats & Actions */}
        <div className="flex items-center justify-between flex-wrap gap-4 mb-6">
          <div className="terminal-border bg-[#0d0d0d] p-4">
            <span className="text-[#4a4a4a] text-xs">{t("TOTAL MESSAGES", "メッセージ総数")}: </span>
            <span className="text-[#0088FF]">{messages.length}</span>
          </div>
          {messages.length > 0 && (
            <button
              onClick={handleClearAll}
              className="terminal-border-red bg-[#0a0a0a] px-4 py-2 text-[#FF0000] text-xs hover:bg-[#FF0000] hover:text-[#0a0a0a] transition-all"
            >
              [{t("CLEAR ALL MESSAGES", "全メッセージを削除")}]
            </button>
          )}
        </div>

        {/* Messages List */}
        <div className="space-y-4">
          {messages.length === 0 ? (
            <div className="terminal-border bg-[#0d0d0d] p-8 text-center">
              <p className="text-[#4a4a4a]">{t("No chat messages", "チャットメッセージはありません")}</p>
            </div>
          ) : (
            messages.map((message) => (
              <div key={message.id} className="terminal-border bg-[#0d0d0d] p-4">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <span className="text-[#00FF41] text-sm">{message.profiles?.codename || "ANON"}</span>
                      {message.profiles?.is_admin && (
                        <span className="text-[#FF0000] text-xs">[{t("AUTHOR", "著者")}]</span>
                      )}
                      <span className="text-[#4a4a4a] text-xs">
                        {new Date(message.created_at).toLocaleString(language === "jp" ? "ja-JP" : "en-US")}
                      </span>
                    </div>
                    <p className="text-[#0088FF] text-sm">{message.content}</p>
                  </div>
                  <button
                    onClick={() => handleDelete(message.id)}
                    disabled={deleting === message.id}
                    className="text-[#FF0000] text-xs hover:underline disabled:opacity-50"
                  >
                    [{deleting === message.id ? "..." : t("DELETE", "削除")}]
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      <SystemFooter />
    </main>
  )
}
