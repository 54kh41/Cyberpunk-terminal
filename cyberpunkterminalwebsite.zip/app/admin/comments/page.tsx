"use client"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { useRouter } from "next/navigation"
import { TerminalNav } from "@/components/terminal-nav"
import { SystemFooter } from "@/components/system-footer"
import { LanguageToggle } from "@/components/language-toggle"
import { useLanguage } from "@/lib/language-context"
import type { Comment, Post } from "@/lib/types"

interface CommentWithPost extends Comment {
  posts?: Post
}

export default function AdminCommentsPage() {
  const [comments, setComments] = useState<CommentWithPost[]>([])
  const [loading, setLoading] = useState(true)
  const [deleting, setDeleting] = useState<string | null>(null)
  const router = useRouter()
  const { t, language } = useLanguage()

  useEffect(() => {
    const init = async () => {
      const supabase = createClient()
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        router.push("/auth/login")
        return
      }

      const { data: profile } = await supabase.from("profiles").select("is_admin").eq("id", user.id).single()

      if (!profile?.is_admin) {
        router.push("/")
        return
      }

      const { data } = await supabase
        .from("comments")
        .select("*, profiles(*), posts(title_en, title_jp)")
        .order("created_at", { ascending: false })
        .limit(100)

      if (data) setComments(data)
      setLoading(false)
    }

    init()
  }, [router])

  const handleDelete = async (commentId: string) => {
    setDeleting(commentId)
    const supabase = createClient()
    const { error } = await supabase.from("comments").delete().eq("id", commentId)

    if (!error) {
      setComments(comments.filter((c) => c.id !== commentId))
    }
    setDeleting(null)
  }

  if (loading) {
    return (
      <main className="min-h-screen flex items-center justify-center">
        <span className="text-[#0088FF] animate-pulse">{t("LOADING...", "読み込み中...")}</span>
      </main>
    )
  }

  return (
    <main className="min-h-screen pb-20">
      <LanguageToggle />
      <div className="max-w-5xl mx-auto p-4 md:p-6">
        <TerminalNav />

        <div className="terminal-border-red bg-[#0a0a0a] p-4 mb-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-[#FF0000] text-xl tracking-widest glow-text">
                // {t("COMMENT MODERATION", "コメント管理")}
              </h1>
              <p className="text-[#4a4a4a] text-xs mt-1">{t("Review and delete comments", "コメントの確認と削除")}</p>
            </div>
            <a href="/admin" className="text-[#0088FF] text-xs hover:text-[#00FF41]">
              [{t("BACK", "戻る")}]
            </a>
          </div>
        </div>

        <div className="terminal-border bg-[#0d0d0d] p-4 mb-6">
          <span className="text-[#4a4a4a] text-xs">{t("TOTAL COMMENTS", "コメント総数")}: </span>
          <span className="text-[#0088FF]">{comments.length}</span>
        </div>

        <div className="space-y-4">
          {comments.length === 0 ? (
            <div className="terminal-border bg-[#0d0d0d] p-8 text-center">
              <p className="text-[#4a4a4a]">{t("No comments yet", "コメントはまだありません")}</p>
            </div>
          ) : (
            comments.map((comment) => (
              <div key={comment.id} className="terminal-border bg-[#0d0d0d] p-4">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <span className="text-[#00FF41] text-sm">{comment.profiles?.codename || "ANON"}</span>
                      <span className="text-[#4a4a4a] text-xs">
                        {new Date(comment.created_at).toLocaleString(language === "jp" ? "ja-JP" : "en-US")}
                      </span>
                    </div>
                    <p className="text-[#0088FF] text-sm mb-2">{comment.content_en}</p>
                    {comment.content_jp && <p className="text-[#4a4a4a] text-xs mb-2">{comment.content_jp}</p>}
                    <p className="text-[#4a4a4a] text-xs">
                      {t("On post", "投稿")}:{" "}
                      {language === "jp" && comment.posts?.title_jp ? comment.posts.title_jp : comment.posts?.title_en}
                    </p>
                  </div>
                  <button
                    onClick={() => handleDelete(comment.id)}
                    disabled={deleting === comment.id}
                    className="text-[#FF0000] text-xs hover:underline disabled:opacity-50"
                  >
                    [{deleting === comment.id ? "..." : t("DELETE", "削除")}]
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      <SystemFooter />
    </main>
  )
}
