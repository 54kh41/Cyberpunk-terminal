"use client"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { useRouter } from "next/navigation"
import { TerminalNav } from "@/components/terminal-nav"
import { SystemFooter } from "@/components/system-footer"
import { LanguageToggle } from "@/components/language-toggle"
import { useLanguage } from "@/lib/language-context"

interface Stats {
  totalUsers: number
  totalPosts: number
  totalComments: number
  totalChatMessages: number
  totalFriendships: number
  recentUsers: number
  recentPosts: number
  recentComments: number
}

export default function AdminStatsPage() {
  const [stats, setStats] = useState<Stats | null>(null)
  const [loading, setLoading] = useState(true)
  const router = useRouter()
  const { t } = useLanguage()

  useEffect(() => {
    const init = async () => {
      const supabase = createClient()
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        router.push("/auth/login")
        return
      }

      const { data: profile } = await supabase.from("profiles").select("is_admin").eq("id", user.id).single()

      if (!profile?.is_admin) {
        router.push("/")
        return
      }

      const sevenDaysAgo = new Date()
      sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7)
      const sevenDaysAgoISO = sevenDaysAgo.toISOString()

      const [
        usersRes,
        postsRes,
        commentsRes,
        chatRes,
        friendshipsRes,
        recentUsersRes,
        recentPostsRes,
        recentCommentsRes,
      ] = await Promise.all([
        supabase.from("profiles").select("id", { count: "exact", head: true }),
        supabase.from("posts").select("id", { count: "exact", head: true }),
        supabase.from("comments").select("id", { count: "exact", head: true }),
        supabase.from("chat_messages").select("id", { count: "exact", head: true }),
        supabase.from("friendships").select("id", { count: "exact", head: true }),
        supabase.from("profiles").select("id", { count: "exact", head: true }).gte("created_at", sevenDaysAgoISO),
        supabase.from("posts").select("id", { count: "exact", head: true }).gte("created_at", sevenDaysAgoISO),
        supabase.from("comments").select("id", { count: "exact", head: true }).gte("created_at", sevenDaysAgoISO),
      ])

      setStats({
        totalUsers: usersRes.count || 0,
        totalPosts: postsRes.count || 0,
        totalComments: commentsRes.count || 0,
        totalChatMessages: chatRes.count || 0,
        totalFriendships: friendshipsRes.count || 0,
        recentUsers: recentUsersRes.count || 0,
        recentPosts: recentPostsRes.count || 0,
        recentComments: recentCommentsRes.count || 0,
      })
      setLoading(false)
    }

    init()
  }, [router])

  if (loading) {
    return (
      <main className="min-h-screen flex items-center justify-center">
        <span className="text-[#0088FF] animate-pulse">{t("LOADING...", "読み込み中...")}</span>
      </main>
    )
  }

  const statCards = [
    { label_en: "TOTAL USERS", label_jp: "総ユーザー数", value: stats?.totalUsers, color: "text-[#00FF41]" },
    { label_en: "TOTAL POSTS", label_jp: "総投稿数", value: stats?.totalPosts, color: "text-[#0088FF]" },
    { label_en: "TOTAL COMMENTS", label_jp: "総コメント数", value: stats?.totalComments, color: "text-[#0088FF]" },
    {
      label_en: "CHAT MESSAGES",
      label_jp: "チャットメッセージ",
      value: stats?.totalChatMessages,
      color: "text-[#0088FF]",
    },
    { label_en: "CONNECTIONS", label_jp: "接続数", value: stats?.totalFriendships, color: "text-[#00FF41]" },
  ]

  const recentCards = [
    { label_en: "NEW USERS (7d)", label_jp: "新規ユーザー (7日)", value: stats?.recentUsers, color: "text-[#00FF41]" },
    { label_en: "NEW POSTS (7d)", label_jp: "新規投稿 (7日)", value: stats?.recentPosts, color: "text-[#0088FF]" },
    {
      label_en: "NEW COMMENTS (7d)",
      label_jp: "新規コメント (7日)",
      value: stats?.recentComments,
      color: "text-[#0088FF]",
    },
  ]

  return (
    <main className="min-h-screen pb-20">
      <LanguageToggle />
      <div className="max-w-5xl mx-auto p-4 md:p-6">
        <TerminalNav />

        <div className="terminal-border-red bg-[#0a0a0a] p-4 mb-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-[#FF0000] text-xl tracking-widest glow-text">
                // {t("SITE STATISTICS", "サイト統計")}
              </h1>
              <p className="text-[#4a4a4a] text-xs mt-1">{t("Overview of all site activity", "サイト活動の概要")}</p>
            </div>
            <a href="/admin" className="text-[#0088FF] text-xs hover:text-[#00FF41]">
              [{t("BACK", "戻る")}]
            </a>
          </div>
        </div>

        {/* All Time Stats */}
        <div className="mb-8">
          <h2 className="text-[#0088FF] text-lg tracking-wider mb-4">// {t("ALL TIME", "累計")}</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {statCards.map((stat) => (
              <div key={stat.label_en} className="terminal-border bg-[#0d0d0d] p-4">
                <div className="text-[#4a4a4a] text-xs mb-2">{t(stat.label_en, stat.label_jp)}</div>
                <div className={`${stat.color} text-3xl font-bold`}>{stat.value}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Recent Activity */}
        <div>
          <h2 className="text-[#0088FF] text-lg tracking-wider mb-4">// {t("RECENT ACTIVITY", "最近の活動")}</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {recentCards.map((stat) => (
              <div key={stat.label_en} className="terminal-border-green bg-[#0d0d0d] p-6">
                <div className="text-[#4a4a4a] text-xs mb-2">{t(stat.label_en, stat.label_jp)}</div>
                <div className={`${stat.color} text-4xl font-bold`}>{stat.value}</div>
              </div>
            ))}
          </div>
        </div>

        {/* System Status */}
        <div className="terminal-border bg-[#0a0a0a] p-6 mt-8">
          <h2 className="text-[#00FF41] text-lg tracking-wider mb-4">// {t("SYSTEM STATUS", "システム状態")}</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs">
            <div>
              <span className="text-[#4a4a4a]">{t("DATABASE", "データベース")}:</span>
              <span className="text-[#00FF41] ml-2">{t("ONLINE", "オンライン")}</span>
            </div>
            <div>
              <span className="text-[#4a4a4a]">{t("STORAGE", "ストレージ")}:</span>
              <span className="text-[#00FF41] ml-2">{t("ONLINE", "オンライン")}</span>
            </div>
            <div>
              <span className="text-[#4a4a4a]">{t("AUTH", "認証")}:</span>
              <span className="text-[#00FF41] ml-2">{t("ONLINE", "オンライン")}</span>
            </div>
            <div>
              <span className="text-[#4a4a4a]">{t("REALTIME", "リアルタイム")}:</span>
              <span className="text-[#00FF41] ml-2">{t("ACTIVE", "アクティブ")}</span>
            </div>
          </div>
        </div>
      </div>

      <SystemFooter />
    </main>
  )
}
