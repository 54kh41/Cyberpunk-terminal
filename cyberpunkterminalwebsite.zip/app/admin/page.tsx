"use client"

import type React from "react"
import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { useRouter } from "next/navigation"
import { LanguageToggle } from "@/components/language-toggle"
import { useLanguage } from "@/lib/language-context"
import { TerminalNav } from "@/components/terminal-nav"
import { SystemFooter } from "@/components/system-footer"
import { FileUpload } from "@/components/file-upload"
import type { PostCategory } from "@/lib/types"

export default function AdminPage() {
  const [user, setUser] = useState<any>(null)
  const [profile, setProfile] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [posts, setPosts] = useState<any[]>([])
  const [categories, setCategories] = useState<PostCategory[]>([])
  const [showCreatePost, setShowCreatePost] = useState(false)
  const [activeTab, setActiveTab] = useState<"posts" | "settings" | "moderation">("posts")
  const [newPost, setNewPost] = useState({
    title_en: "",
    title_jp: "",
    content_en: "",
    content_jp: "",
    image_url: "",
    video_url: "",
    category: "general",
    is_pinned: false,
  })
  const [authorSettings, setAuthorSettings] = useState({
    banner_url: "",
    avatar_url: "",
    display_name_en: "",
    display_name_jp: "",
    bio_en: "",
    bio_jp: "",
    facebook_url: "",
    instagram_url: "",
    tiktok_url: "",
    twitter_url: "",
    youtube_url: "",
    discord_url: "",
    royal_road_url: "",
    kakuyomu_url: "",
  })
  const [submitting, setSubmitting] = useState(false)
  const [savingSettings, setSavingSettings] = useState(false)
  const router = useRouter()
  const { t } = useLanguage()

  useEffect(() => {
    const checkAuth = async () => {
      const supabase = createClient()
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        router.push("/auth/login")
        return
      }

      setUser(user)

      const { data: profileData } = await supabase.from("profiles").select("*").eq("id", user.id).single()

      if (!profileData?.is_admin) {
        router.push("/")
        return
      }

      setProfile(profileData)

      // Fetch posts, categories, and author settings in parallel
      const [postsRes, categoriesRes, settingsRes] = await Promise.all([
        supabase
          .from("posts")
          .select("*")
          .order("is_pinned", { ascending: false })
          .order("created_at", { ascending: false }),
        supabase.from("post_categories").select("*"),
        supabase.from("author_settings").select("*").eq("user_id", user.id).single(),
      ])

      if (postsRes.data) setPosts(postsRes.data)
      if (categoriesRes.data) setCategories(categoriesRes.data)
      if (settingsRes.data) {
        setAuthorSettings({
          banner_url: settingsRes.data.banner_url || "",
          avatar_url: settingsRes.data.avatar_url || "",
          display_name_en: settingsRes.data.display_name_en || "",
          display_name_jp: settingsRes.data.display_name_jp || "",
          bio_en: settingsRes.data.bio_en || "",
          bio_jp: settingsRes.data.bio_jp || "",
          facebook_url: settingsRes.data.facebook_url || "",
          instagram_url: settingsRes.data.instagram_url || "",
          tiktok_url: settingsRes.data.tiktok_url || "",
          twitter_url: settingsRes.data.twitter_url || "",
          youtube_url: settingsRes.data.youtube_url || "",
          discord_url: settingsRes.data.discord_url || "",
          royal_road_url: settingsRes.data.royal_road_url || "",
          kakuyomu_url: settingsRes.data.kakuyomu_url || "",
        })
      }

      setLoading(false)
    }

    checkAuth()
  }, [router])

  const handleCreatePost = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!newPost.title_en.trim() || !newPost.content_en.trim()) return

    setSubmitting(true)
    const supabase = createClient()

    const { data, error } = await supabase
      .from("posts")
      .insert({
        author_id: user.id,
        title_en: newPost.title_en,
        title_jp: newPost.title_jp || null,
        content_en: newPost.content_en,
        content_jp: newPost.content_jp || null,
        image_url: newPost.image_url || null,
        video_url: newPost.video_url || null,
        category: newPost.category,
        is_pinned: newPost.is_pinned,
      })
      .select()

    if (!error && data) {
      setPosts([data[0], ...posts])
      setNewPost({
        title_en: "",
        title_jp: "",
        content_en: "",
        content_jp: "",
        image_url: "",
        video_url: "",
        category: "general",
        is_pinned: false,
      })
      setShowCreatePost(false)
    }
    setSubmitting(false)
  }

  const handleDeletePost = async (postId: string) => {
    const supabase = createClient()
    const { error } = await supabase.from("posts").delete().eq("id", postId)
    if (!error) {
      setPosts(posts.filter((p) => p.id !== postId))
    }
  }

  const handleTogglePin = async (postId: string, currentPinned: boolean) => {
    const supabase = createClient()
    const { error } = await supabase.from("posts").update({ is_pinned: !currentPinned }).eq("id", postId)
    if (!error) {
      setPosts(posts.map((p) => (p.id === postId ? { ...p, is_pinned: !currentPinned } : p)))
    }
  }

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault()
    setSavingSettings(true)
    const supabase = createClient()

    const { error } = await supabase.from("author_settings").upsert({
      user_id: user.id,
      ...authorSettings,
      updated_at: new Date().toISOString(),
    })

    setSavingSettings(false)
  }

  if (loading) {
    return (
      <main className="min-h-screen flex items-center justify-center">
        <span className="text-[#0088FF] animate-pulse">
          {t("LOADING ADMIN CONSOLE...", "管理コンソール読み込み中...")}
        </span>
      </main>
    )
  }

  return (
    <main className="min-h-screen pb-20">
      <LanguageToggle />
      <div className="max-w-5xl mx-auto p-4 md:p-6">
        <TerminalNav />

        {/* Admin Header */}
        <div className="terminal-border-red bg-[#0a0a0a] p-4 mb-6">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div className="space-y-1">
              <h1 className="text-[#FF0000] text-xl md:text-2xl tracking-widest glow-text">
                // {t("ADMIN_CONSOLE", "管理コンソール")}
              </h1>
              <p className="text-[#4a4a4a] text-xs">
                {t("AUTHOR CONTROL PANEL", "著者コントロールパネル")} // {t("CLEARANCE", "クリアランス")}:{" "}
                <span className="text-[#FF0000]">OMEGA</span>
              </p>
            </div>
            <div className="text-right text-xs">
              <div className="text-[#4a4a4a]">
                {t("LOGGED IN AS", "ログイン中")}: <span className="text-[#00FF41]">{profile?.codename}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex gap-2 mb-6 flex-wrap">
          {(["posts", "settings", "moderation"] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`terminal-border px-4 py-2 text-xs tracking-wider transition-all ${
                activeTab === tab ? "bg-[#0088FF] text-[#0a0a0a]" : "bg-[#0a0a0a] text-[#0088FF] hover:bg-[#111]"
              }`}
            >
              [{t(tab.toUpperCase(), tab === "posts" ? "投稿" : tab === "settings" ? "設定" : "管理")}]
            </button>
          ))}
        </div>

        {/* Posts Tab */}
        {activeTab === "posts" && (
          <>
            {/* Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              <div className="terminal-border bg-[#0d0d0d] p-4">
                <div className="text-[#4a4a4a] text-xs mb-1">{t("TOTAL_POSTS", "総投稿数")}</div>
                <div className="text-[#0088FF] text-2xl font-bold">{posts.length}</div>
              </div>
              <div className="terminal-border bg-[#0d0d0d] p-4">
                <div className="text-[#4a4a4a] text-xs mb-1">{t("PINNED", "固定")}</div>
                <div className="text-[#FFD700] text-2xl font-bold">{posts.filter((p) => p.is_pinned).length}</div>
              </div>
            </div>

            {/* Create Post Button */}
            <button
              onClick={() => setShowCreatePost(!showCreatePost)}
              className="terminal-border-green bg-[#0a0a0a] px-6 py-3 text-[#00FF41] text-sm tracking-wider hover:bg-[#00FF41] hover:text-[#0a0a0a] transition-all mb-6"
            >
              {showCreatePost ? t("[CANCEL]", "[キャンセル]") : t("[CREATE NEW POST]", "[新規投稿作成]")}
            </button>

            {/* Create Post Form */}
            {showCreatePost && (
              <form onSubmit={handleCreatePost} className="terminal-border bg-[#0d0d0d] p-6 mb-6 space-y-4">
                <h2 className="text-[#0088FF] text-lg tracking-wider mb-4">{t("NEW TRANSMISSION", "新しい送信")}</h2>

                {/* Category & Pin */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-[#4a4a4a] text-xs block">{t("CATEGORY", "カテゴリ")}</label>
                    <select
                      value={newPost.category}
                      onChange={(e) => setNewPost({ ...newPost, category: e.target.value })}
                      className="w-full bg-[#111] border border-[#1a1a1a] text-[#0088FF] p-3 focus:border-[#0088FF] focus:outline-none"
                    >
                      {categories.map((cat) => (
                        <option key={cat.slug} value={cat.slug}>
                          {cat.name_en}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="flex items-center gap-3 pt-6">
                    <input
                      type="checkbox"
                      id="is_pinned"
                      checked={newPost.is_pinned}
                      onChange={(e) => setNewPost({ ...newPost, is_pinned: e.target.checked })}
                      className="w-4 h-4 accent-[#FFD700]"
                    />
                    <label htmlFor="is_pinned" className="text-[#FFD700] text-sm">
                      {t("PIN THIS POST", "この投稿を固定")} 📌
                    </label>
                  </div>
                </div>

                {/* Titles */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-[#4a4a4a] text-xs block">{t("TITLE (EN)", "タイトル (英語)")}*</label>
                    <input
                      type="text"
                      value={newPost.title_en}
                      onChange={(e) => setNewPost({ ...newPost, title_en: e.target.value })}
                      required
                      className="w-full bg-[#111] border border-[#1a1a1a] text-[#0088FF] p-3 focus:border-[#0088FF] focus:outline-none"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[#4a4a4a] text-xs block">{t("TITLE (JP)", "タイトル (日本語)")}</label>
                    <input
                      type="text"
                      value={newPost.title_jp}
                      onChange={(e) => setNewPost({ ...newPost, title_jp: e.target.value })}
                      className="w-full bg-[#111] border border-[#1a1a1a] text-[#0088FF] p-3 focus:border-[#0088FF] focus:outline-none"
                    />
                  </div>
                </div>

                {/* Content */}
                <div className="space-y-2">
                  <label className="text-[#4a4a4a] text-xs block">{t("CONTENT (EN)", "内容 (英語)")}*</label>
                  <textarea
                    value={newPost.content_en}
                    onChange={(e) => setNewPost({ ...newPost, content_en: e.target.value })}
                    required
                    rows={6}
                    className="w-full bg-[#111] border border-[#1a1a1a] text-[#0088FF] p-3 focus:border-[#0088FF] focus:outline-none resize-none"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-[#4a4a4a] text-xs block">{t("CONTENT (JP)", "内容 (日本語)")}</label>
                  <textarea
                    value={newPost.content_jp}
                    onChange={(e) => setNewPost({ ...newPost, content_jp: e.target.value })}
                    rows={6}
                    className="w-full bg-[#111] border border-[#1a1a1a] text-[#0088FF] p-3 focus:border-[#0088FF] focus:outline-none resize-none"
                  />
                </div>

                {/* Image Upload */}
                <div className="space-y-2">
                  <label className="text-[#4a4a4a] text-xs block">{t("IMAGE", "画像")}</label>
                  <FileUpload
                    uploadType="posts"
                    accept="image/*"
                    onUpload={(url) => setNewPost({ ...newPost, image_url: url })}
                  />
                  {newPost.image_url && (
                    <div className="mt-2">
                      <img
                        src={newPost.image_url || "/placeholder.svg"}
                        alt="Preview"
                        className="max-h-40 object-contain"
                      />
                      <button
                        type="button"
                        onClick={() => setNewPost({ ...newPost, image_url: "" })}
                        className="text-[#FF0000] text-xs mt-1"
                      >
                        [{t("REMOVE", "削除")}]
                      </button>
                    </div>
                  )}
                </div>

                {/* Video Upload */}
                <div className="space-y-2">
                  <label className="text-[#4a4a4a] text-xs block">{t("VIDEO", "動画")}</label>
                  <FileUpload
                    uploadType="posts"
                    accept="video/*"
                    maxSizeMB={100}
                    onUpload={(url) => setNewPost({ ...newPost, video_url: url })}
                  />
                  {newPost.video_url && (
                    <div className="mt-2">
                      <video src={newPost.video_url} controls className="max-h-40" />
                      <button
                        type="button"
                        onClick={() => setNewPost({ ...newPost, video_url: "" })}
                        className="text-[#FF0000] text-xs mt-1"
                      >
                        [{t("REMOVE", "削除")}]
                      </button>
                    </div>
                  )}
                </div>

                <button
                  type="submit"
                  disabled={submitting}
                  className="terminal-border-green bg-[#0a0a0a] px-6 py-3 text-[#00FF41] text-sm tracking-wider hover:bg-[#00FF41] hover:text-[#0a0a0a] transition-all disabled:opacity-50"
                >
                  {submitting ? t("TRANSMITTING...", "送信中...") : t("[PUBLISH POST]", "[投稿を公開]")}
                </button>
              </form>
            )}

            {/* Posts List */}
            <div className="space-y-4">
              <h2 className="text-[#0088FF] text-lg tracking-wider">{t("ALL TRANSMISSIONS", "全ての送信")}</h2>
              {posts.length === 0 ? (
                <div className="terminal-border bg-[#0d0d0d] p-8 text-center">
                  <p className="text-[#4a4a4a]">
                    {t(
                      "No posts yet. Create your first transmission!",
                      "投稿はまだありません。最初の送信を作成してください！",
                    )}
                  </p>
                </div>
              ) : (
                posts.map((post) => (
                  <div
                    key={post.id}
                    className={`terminal-border bg-[#0d0d0d] p-4 ${post.is_pinned ? "border-[#FFD700]" : ""}`}
                  >
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          {post.is_pinned && <span className="text-[#FFD700]">📌</span>}
                          <span className="text-[#4a4a4a] text-xs px-2 py-0.5 bg-[#1a1a1a] rounded">
                            {categories.find((c) => c.slug === post.category)?.name_en || post.category}
                          </span>
                        </div>
                        <h3 className="text-[#00FF41] text-lg">{post.title_en}</h3>
                        {post.title_jp && <p className="text-[#4a4a4a] text-sm">{post.title_jp}</p>}
                        <p className="text-[#0088FF] text-sm mt-2 line-clamp-2">{post.content_en}</p>
                        <p className="text-[#4a4a4a] text-xs mt-2">{new Date(post.created_at).toLocaleString()}</p>
                      </div>
                      <div className="flex flex-col gap-2">
                        <button
                          onClick={() => handleTogglePin(post.id, post.is_pinned)}
                          className="text-[#FFD700] text-xs hover:underline"
                        >
                          [{post.is_pinned ? t("UNPIN", "固定解除") : t("PIN", "固定")}]
                        </button>
                        <button
                          onClick={() => handleDeletePost(post.id)}
                          className="text-[#FF0000] text-xs hover:underline"
                        >
                          [{t("DELETE", "削除")}]
                        </button>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </>
        )}

        {/* Settings Tab - Author Profile */}
        {activeTab === "settings" && (
          <form onSubmit={handleSaveSettings} className="space-y-6">
            <div className="terminal-border bg-[#0d0d0d] p-6">
              <h2 className="text-[#0088FF] text-lg tracking-wider mb-6">{t("AUTHOR PROFILE", "著者プロフィール")}</h2>

              {/* Banner Upload */}
              <div className="space-y-4 mb-6">
                <label className="text-[#4a4a4a] text-xs block">{t("SITE BANNER", "サイトバナー")}</label>
                <FileUpload
                  uploadType="banner"
                  accept="image/*"
                  onUpload={(url) => setAuthorSettings({ ...authorSettings, banner_url: url })}
                />
                {authorSettings.banner_url && (
                  <div className="terminal-border p-2">
                    <img
                      src={authorSettings.banner_url || "/placeholder.svg"}
                      alt="Banner Preview"
                      className="w-full h-32 object-cover"
                    />
                    <button
                      type="button"
                      onClick={() => setAuthorSettings({ ...authorSettings, banner_url: "" })}
                      className="text-[#FF0000] text-xs mt-2"
                    >
                      [{t("REMOVE", "削除")}]
                    </button>
                  </div>
                )}
              </div>

              {/* Avatar Upload */}
              <div className="space-y-4 mb-6">
                <label className="text-[#4a4a4a] text-xs block">{t("AUTHOR AVATAR", "著者アバター")}</label>
                <FileUpload
                  uploadType="avatar"
                  accept="image/*"
                  onUpload={(url) => setAuthorSettings({ ...authorSettings, avatar_url: url })}
                />
                {authorSettings.avatar_url && (
                  <div className="flex items-center gap-4">
                    <img
                      src={authorSettings.avatar_url || "/placeholder.svg"}
                      alt="Avatar"
                      className="w-20 h-20 rounded-full object-cover border-2 border-[#0088FF]"
                    />
                    <button
                      type="button"
                      onClick={() => setAuthorSettings({ ...authorSettings, avatar_url: "" })}
                      className="text-[#FF0000] text-xs"
                    >
                      [{t("REMOVE", "削除")}]
                    </button>
                  </div>
                )}
              </div>

              {/* Display Names */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <div className="space-y-2">
                  <label className="text-[#4a4a4a] text-xs block">{t("DISPLAY NAME (EN)", "表示名 (英語)")}</label>
                  <input
                    type="text"
                    value={authorSettings.display_name_en}
                    onChange={(e) => setAuthorSettings({ ...authorSettings, display_name_en: e.target.value })}
                    className="w-full bg-[#111] border border-[#1a1a1a] text-[#0088FF] p-3 focus:border-[#0088FF] focus:outline-none"
                    placeholder="Your pen name"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[#4a4a4a] text-xs block">{t("DISPLAY NAME (JP)", "表示名 (日本語)")}</label>
                  <input
                    type="text"
                    value={authorSettings.display_name_jp}
                    onChange={(e) => setAuthorSettings({ ...authorSettings, display_name_jp: e.target.value })}
                    className="w-full bg-[#111] border border-[#1a1a1a] text-[#0088FF] p-3 focus:border-[#0088FF] focus:outline-none"
                    placeholder="ペンネーム"
                  />
                </div>
              </div>

              {/* Bios */}
              <div className="space-y-4 mb-6">
                <div className="space-y-2">
                  <label className="text-[#4a4a4a] text-xs block">{t("BIO (EN)", "自己紹介 (英語)")}</label>
                  <textarea
                    value={authorSettings.bio_en}
                    onChange={(e) => setAuthorSettings({ ...authorSettings, bio_en: e.target.value })}
                    rows={4}
                    className="w-full bg-[#111] border border-[#1a1a1a] text-[#0088FF] p-3 focus:border-[#0088FF] focus:outline-none resize-none"
                    placeholder="Tell your readers about yourself..."
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[#4a4a4a] text-xs block">{t("BIO (JP)", "自己紹介 (日本語)")}</label>
                  <textarea
                    value={authorSettings.bio_jp}
                    onChange={(e) => setAuthorSettings({ ...authorSettings, bio_jp: e.target.value })}
                    rows={4}
                    className="w-full bg-[#111] border border-[#1a1a1a] text-[#0088FF] p-3 focus:border-[#0088FF] focus:outline-none resize-none"
                    placeholder="読者に自己紹介..."
                  />
                </div>
              </div>
            </div>

            {/* Social Links */}
            <div className="terminal-border bg-[#0d0d0d] p-6">
              <h2 className="text-[#0088FF] text-lg tracking-wider mb-6">{t("SOCIAL LINKS", "ソーシャルリンク")}</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {[
                  { key: "facebook_url", label: "Facebook", icon: "📘" },
                  { key: "instagram_url", label: "Instagram", icon: "📷" },
                  { key: "tiktok_url", label: "TikTok", icon: "🎵" },
                  { key: "twitter_url", label: "X (Twitter)", icon: "🐦" },
                  { key: "youtube_url", label: "YouTube", icon: "📺" },
                  { key: "discord_url", label: "Discord", icon: "💬" },
                ].map(({ key, label, icon }) => (
                  <div key={key} className="space-y-2">
                    <label className="text-[#4a4a4a] text-xs flex items-center gap-2">
                      <span>{icon}</span> {label}
                    </label>
                    <input
                      type="url"
                      value={authorSettings[key as keyof typeof authorSettings]}
                      onChange={(e) => setAuthorSettings({ ...authorSettings, [key]: e.target.value })}
                      className="w-full bg-[#111] border border-[#1a1a1a] text-[#0088FF] p-3 focus:border-[#0088FF] focus:outline-none text-sm"
                      placeholder={`https://${label.toLowerCase()}.com/...`}
                    />
                  </div>
                ))}
              </div>
            </div>

            {/* Novel Platform Links */}
            <div className="terminal-border bg-[#0d0d0d] p-6">
              <h2 className="text-[#0088FF] text-lg tracking-wider mb-6">
                {t("NOVEL PLATFORMS", "小説プラットフォーム")}
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-[#4a4a4a] text-xs flex items-center gap-2">
                    <span>📖</span> Royal Road
                  </label>
                  <input
                    type="url"
                    value={authorSettings.royal_road_url}
                    onChange={(e) => setAuthorSettings({ ...authorSettings, royal_road_url: e.target.value })}
                    className="w-full bg-[#111] border border-[#1a1a1a] text-[#0088FF] p-3 focus:border-[#0088FF] focus:outline-none text-sm"
                    placeholder="https://www.royalroad.com/fiction/..."
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[#4a4a4a] text-xs flex items-center gap-2">
                    <span>📚</span> Kakuyomu (カクヨム)
                  </label>
                  <input
                    type="url"
                    value={authorSettings.kakuyomu_url}
                    onChange={(e) => setAuthorSettings({ ...authorSettings, kakuyomu_url: e.target.value })}
                    className="w-full bg-[#111] border border-[#1a1a1a] text-[#0088FF] p-3 focus:border-[#0088FF] focus:outline-none text-sm"
                    placeholder="https://kakuyomu.jp/works/..."
                  />
                </div>
              </div>
            </div>

            <button
              type="submit"
              disabled={savingSettings}
              className="terminal-border-green bg-[#0a0a0a] px-6 py-3 text-[#00FF41] text-sm tracking-wider hover:bg-[#00FF41] hover:text-[#0a0a0a] transition-all disabled:opacity-50"
            >
              {savingSettings ? t("SAVING...", "保存中...") : t("[SAVE SETTINGS]", "[設定を保存]")}
            </button>
          </form>
        )}

        {/* Moderation Tab */}
        {activeTab === "moderation" && (
          <div className="space-y-6">
            <div className="terminal-border bg-[#0d0d0d] p-6">
              <h2 className="text-[#FF0000] text-lg tracking-wider mb-4">{t("MODERATION TOOLS", "管理ツール")}</h2>
              <p className="text-[#4a4a4a] text-sm mb-6">
                {t("Manage comments, users, and chat from here.", "ここからコメント、ユーザー、チャットを管理します。")}
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <a
                  href="/admin/comments"
                  className="terminal-border bg-[#0a0a0a] p-4 hover:bg-[#111] transition-all block"
                >
                  <h3 className="text-[#0088FF] text-sm mb-2">{t("MANAGE COMMENTS", "コメント管理")}</h3>
                  <p className="text-[#4a4a4a] text-xs">{t("Review and delete comments", "コメントの確認と削除")}</p>
                </a>
                <a
                  href="/admin/users"
                  className="terminal-border bg-[#0a0a0a] p-4 hover:bg-[#111] transition-all block"
                >
                  <h3 className="text-[#0088FF] text-sm mb-2">{t("MANAGE USERS", "ユーザー管理")}</h3>
                  <p className="text-[#4a4a4a] text-xs">{t("View and block users", "ユーザーの確認とブロック")}</p>
                </a>
                <a href="/admin/chat" className="terminal-border bg-[#0a0a0a] p-4 hover:bg-[#111] transition-all block">
                  <h3 className="text-[#0088FF] text-sm mb-2">{t("CHAT HISTORY", "チャット履歴")}</h3>
                  <p className="text-[#4a4a4a] text-xs">{t("View all chat messages", "全チャットメッセージを確認")}</p>
                </a>
                <a
                  href="/admin/stats"
                  className="terminal-border bg-[#0a0a0a] p-4 hover:bg-[#111] transition-all block"
                >
                  <h3 className="text-[#0088FF] text-sm mb-2">{t("STATISTICS", "統計")}</h3>
                  <p className="text-[#4a4a4a] text-xs">{t("View site analytics", "サイト分析を確認")}</p>
                </a>
              </div>
            </div>
          </div>
        )}
      </div>

      <SystemFooter />
    </main>
  )
}
