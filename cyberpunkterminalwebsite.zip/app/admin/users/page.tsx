"use client"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { useRouter } from "next/navigation"
import { TerminalNav } from "@/components/terminal-nav"
import { SystemFooter } from "@/components/system-footer"
import { LanguageToggle } from "@/components/language-toggle"
import { useLanguage } from "@/lib/language-context"
import type { Profile } from "@/lib/types"

export default function AdminUsersPage() {
  const [users, setUsers] = useState<Profile[]>([])
  const [blockedUsers, setBlockedUsers] = useState<{ id: string; blocked_id: string; blocked?: Profile }[]>([])
  const [loading, setLoading] = useState(true)
  const [currentUserId, setCurrentUserId] = useState<string | null>(null)
  const [searchQuery, setSearchQuery] = useState("")
  const router = useRouter()
  const { t, language } = useLanguage()

  useEffect(() => {
    const init = async () => {
      const supabase = createClient()
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        router.push("/auth/login")
        return
      }

      setCurrentUserId(user.id)

      const { data: profile } = await supabase.from("profiles").select("is_admin").eq("id", user.id).single()

      if (!profile?.is_admin) {
        router.push("/")
        return
      }

      const [usersRes, blockedRes] = await Promise.all([
        supabase.from("profiles").select("*").order("created_at", { ascending: false }),
        supabase
          .from("blocked_users")
          .select("*, blocked:profiles!blocked_users_blocked_id_fkey(*)")
          .eq("blocker_id", user.id),
      ])

      if (usersRes.data) setUsers(usersRes.data)
      if (blockedRes.data) setBlockedUsers(blockedRes.data)
      setLoading(false)
    }

    init()
  }, [router])

  const handleBlockUser = async (userId: string) => {
    if (!currentUserId) return

    const supabase = createClient()
    const { data, error } = await supabase
      .from("blocked_users")
      .insert({ blocker_id: currentUserId, blocked_id: userId })
      .select("*, blocked:profiles!blocked_users_blocked_id_fkey(*)")
      .single()

    if (!error && data) {
      setBlockedUsers([...blockedUsers, data])
    }
  }

  const handleUnblockUser = async (blockedRecordId: string) => {
    const supabase = createClient()
    const { error } = await supabase.from("blocked_users").delete().eq("id", blockedRecordId)

    if (!error) {
      setBlockedUsers(blockedUsers.filter((b) => b.id !== blockedRecordId))
    }
  }

  const filteredUsers = users.filter((u) => u.codename.toLowerCase().includes(searchQuery.toLowerCase()))

  const isBlocked = (userId: string) => blockedUsers.some((b) => b.blocked_id === userId)

  const getBlockRecord = (userId: string) => blockedUsers.find((b) => b.blocked_id === userId)

  if (loading) {
    return (
      <main className="min-h-screen flex items-center justify-center">
        <span className="text-[#0088FF] animate-pulse">{t("LOADING...", "読み込み中...")}</span>
      </main>
    )
  }

  return (
    <main className="min-h-screen pb-20">
      <LanguageToggle />
      <div className="max-w-5xl mx-auto p-4 md:p-6">
        <TerminalNav />

        <div className="terminal-border-red bg-[#0a0a0a] p-4 mb-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-[#FF0000] text-xl tracking-widest glow-text">
                // {t("USER MANAGEMENT", "ユーザー管理")}
              </h1>
              <p className="text-[#4a4a4a] text-xs mt-1">{t("View and block users", "ユーザーの確認とブロック")}</p>
            </div>
            <a href="/admin" className="text-[#0088FF] text-xs hover:text-[#00FF41]">
              [{t("BACK", "戻る")}]
            </a>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-6">
          <div className="terminal-border bg-[#0d0d0d] p-4">
            <div className="text-[#4a4a4a] text-xs mb-1">{t("TOTAL USERS", "総ユーザー数")}</div>
            <div className="text-[#0088FF] text-2xl font-bold">{users.length}</div>
          </div>
          <div className="terminal-border bg-[#0d0d0d] p-4">
            <div className="text-[#4a4a4a] text-xs mb-1">{t("BLOCKED", "ブロック中")}</div>
            <div className="text-[#FF0000] text-2xl font-bold">{blockedUsers.length}</div>
          </div>
          <div className="terminal-border bg-[#0d0d0d] p-4">
            <div className="text-[#4a4a4a] text-xs mb-1">{t("ADMINS", "管理者")}</div>
            <div className="text-[#00FF41] text-2xl font-bold">{users.filter((u) => u.is_admin).length}</div>
          </div>
        </div>

        {/* Search */}
        <div className="terminal-border bg-[#0d0d0d] p-4 mb-6">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={t("Search by codename...", "コードネームで検索...")}
            className="w-full bg-[#111] border border-[#1a1a1a] text-[#0088FF] p-3 focus:border-[#0088FF] focus:outline-none"
          />
        </div>

        {/* Users List */}
        <div className="space-y-4">
          <h2 className="text-[#0088FF] text-lg tracking-wider">
            {t("ALL USERS", "全ユーザー")} ({filteredUsers.length})
          </h2>

          {filteredUsers.map((user) => (
            <div
              key={user.id}
              className={`terminal-border bg-[#0d0d0d] p-4 ${isBlocked(user.id) ? "border-[#FF0000] opacity-60" : ""}`}
            >
              <div className="flex items-center justify-between flex-wrap gap-4">
                <div className="flex items-center gap-3">
                  <span className="text-[#00FF41]">{user.is_admin ? "★" : "◈"}</span>
                  <div>
                    <span className="text-[#00FF41] tracking-wider">{user.codename}</span>
                    {user.is_admin && <span className="text-[#FF0000] text-xs ml-2">[{t("ADMIN", "管理者")}]</span>}
                    {isBlocked(user.id) && (
                      <span className="text-[#FF0000] text-xs ml-2">[{t("BLOCKED", "ブロック中")}]</span>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <span className="text-[#4a4a4a] text-xs">
                    {new Date(user.created_at).toLocaleDateString(language === "jp" ? "ja-JP" : "en-US")}
                  </span>
                  {user.id !== currentUserId &&
                    !user.is_admin &&
                    (isBlocked(user.id) ? (
                      <button
                        onClick={() => {
                          const record = getBlockRecord(user.id)
                          if (record) handleUnblockUser(record.id)
                        }}
                        className="terminal-border-green bg-[#0a0a0a] px-4 py-2 text-[#00FF41] text-xs hover:bg-[#00FF41] hover:text-[#0a0a0a] transition-all"
                      >
                        [{t("UNBLOCK", "解除")}]
                      </button>
                    ) : (
                      <button
                        onClick={() => handleBlockUser(user.id)}
                        className="terminal-border-red bg-[#0a0a0a] px-4 py-2 text-[#FF0000] text-xs hover:bg-[#FF0000] hover:text-[#0a0a0a] transition-all"
                      >
                        [{t("BLOCK", "ブロック")}]
                      </button>
                    ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <SystemFooter />
    </main>
  )
}
