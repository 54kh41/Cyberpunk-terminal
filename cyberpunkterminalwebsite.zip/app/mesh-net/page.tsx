"use client"

import type React from "react"
import { useState, useEffect, useRef } from "react"
import { createClient } from "@/lib/supabase/client"
import { TerminalNav } from "@/components/terminal-nav"
import { SystemFooter } from "@/components/system-footer"
import { LanguageToggle } from "@/components/language-toggle"
import { useLanguage } from "@/lib/language-context"
import type { ChatMessage, Profile } from "@/lib/types"

interface TranslatedChatMessage extends ChatMessage {
  translatedContent?: string
  isTranslating?: boolean
}

export default function MeshNetPage() {
  const [messages, setMessages] = useState<TranslatedChatMessage[]>([])
  const [newMessage, setNewMessage] = useState("")
  const [user, setUser] = useState<any>(null)
  const [profile, setProfile] = useState<Profile | null>(null)
  const [blockedUsers, setBlockedUsers] = useState<string[]>([])
  const [loading, setLoading] = useState(true)
  const [sending, setSending] = useState(false)
  const [activeUsers, setActiveUsers] = useState(1)
  const [showBlockMenu, setShowBlockMenu] = useState<string | null>(null)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const { t, language } = useLanguage()

  useEffect(() => {
    const supabase = createClient()

    // Check auth and get blocked users
    supabase.auth.getUser().then(async ({ data }) => {
      setUser(data.user)
      if (data.user) {
        const [profileRes, blockedRes] = await Promise.all([
          supabase.from("profiles").select("*").eq("id", data.user.id).single(),
          supabase.from("blocked_users").select("blocked_id").eq("blocker_id", data.user.id),
        ])
        if (profileRes.data) setProfile(profileRes.data)
        if (blockedRes.data) setBlockedUsers(blockedRes.data.map((b) => b.blocked_id))
      }
    })

    // Fetch messages
    const fetchMessages = async () => {
      const { data, error } = await supabase
        .from("chat_messages")
        .select("*, profiles(*)")
        .order("created_at", { ascending: true })
        .limit(100)

      if (!error && data) {
        setMessages(data)
      }
      setLoading(false)
    }

    fetchMessages()

    // Subscribe to new messages
    const channel = supabase
      .channel("chat-room")
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "chat_messages" }, async (payload) => {
        const { data } = await supabase.from("chat_messages").select("*, profiles(*)").eq("id", payload.new.id).single()

        if (data) {
          setMessages((prev) => [...prev, data])
        }
      })
      .on("presence", { event: "sync" }, () => {
        const state = channel.presenceState()
        setActiveUsers(Object.keys(state).length || 1)
      })
      .subscribe(async (status) => {
        if (status === "SUBSCRIBED" && user) {
          await channel.track({ user_id: user.id })
        }
      })

    return () => {
      supabase.removeChannel(channel)
    }
  }, [user])

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!newMessage.trim() || !user || !profile) return

    setSending(true)
    const supabase = createClient()

    const { error } = await supabase.from("chat_messages").insert({
      author_id: user.id,
      content: newMessage,
    })

    if (!error) {
      setNewMessage("")
    }
    setSending(false)
  }

  const handleBlockUser = async (userId: string) => {
    if (!user) return
    const supabase = createClient()
    const { error } = await supabase.from("blocked_users").insert({ blocker_id: user.id, blocked_id: userId })

    if (!error) {
      setBlockedUsers([...blockedUsers, userId])
    }
    setShowBlockMenu(null)
  }

  const handleUnblockUser = async (userId: string) => {
    if (!user) return
    const supabase = createClient()
    const { error } = await supabase.from("blocked_users").delete().eq("blocker_id", user.id).eq("blocked_id", userId)

    if (!error) {
      setBlockedUsers(blockedUsers.filter((id) => id !== userId))
    }
    setShowBlockMenu(null)
  }

  const handleTranslate = async (messageId: string, originalText: string) => {
    setMessages((prev) => prev.map((m) => (m.id === messageId ? { ...m, isTranslating: true } : m)))

    try {
      const targetLang = language === "jp" ? "jp" : "en"
      const isJapanese = /[\u3040-\u309F\u30A0-\u30FF\u4E00-\u9FAF]/.test(originalText)
      const shouldTranslate = (language === "jp" && !isJapanese) || (language === "en" && isJapanese)

      if (!shouldTranslate) {
        setMessages((prev) =>
          prev.map((m) => (m.id === messageId ? { ...m, isTranslating: false, translatedContent: originalText } : m)),
        )
        return
      }

      const response = await fetch("/api/translate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: originalText, targetLanguage: targetLang }),
      })

      if (response.ok) {
        const { translatedText } = await response.json()
        setMessages((prev) =>
          prev.map((m) => (m.id === messageId ? { ...m, isTranslating: false, translatedContent: translatedText } : m)),
        )
      } else {
        setMessages((prev) => prev.map((m) => (m.id === messageId ? { ...m, isTranslating: false } : m)))
      }
    } catch (error) {
      setMessages((prev) => prev.map((m) => (m.id === messageId ? { ...m, isTranslating: false } : m)))
    }
  }

  const visibleMessages = messages.filter((msg) => !blockedUsers.includes(msg.author_id))

  return (
    <main className="min-h-screen pb-20">
      <LanguageToggle />
      <div className="max-w-5xl mx-auto p-4 md:p-6">
        <TerminalNav />

        {/* Header */}
        <div className="terminal-border bg-[#0a0a0a] p-4 mb-6">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div className="space-y-1">
              <h1 className="text-[#00FF41] text-xl md:text-2xl tracking-widest glow-text">
                // {t("MESH-NET_COMMUNICATION", "メッシュネット通信")}
              </h1>
              <p className="text-[#4a4a4a] text-xs">
                {t("ENCRYPTED_CHANNEL", "暗号化チャンネル")} //{" "}
                <span className="text-[#FF0000]">{t("REAL-TIME", "リアルタイム")}</span>
              </p>
            </div>
            <div className="text-xs space-y-1 text-right">
              <div className="text-[#4a4a4a]">
                {t("ACTIVE_NODES", "アクティブノード")}: <span className="text-[#00FF41]">{activeUsers}</span>
              </div>
              <div className="text-[#4a4a4a]">
                {t("LATENCY", "レイテンシ")}: <span className="text-[#0088FF]">{"<"}50ms</span>
              </div>
            </div>
          </div>
        </div>

        {/* Warning Banner */}
        <div className="terminal-border-red bg-[#0a0a0a] p-4 mb-6">
          <div className="text-xs text-[#FF0000] space-y-1">
            <div className="flex items-center gap-2">
              <span className="animate-pulse">!</span>
              <span>{t("ALL COMMUNICATIONS ARE LOGGED", "全ての通信は記録されます")}</span>
            </div>
            <div className="text-[#4a4a4a]">
              {t("Be respectful. This is a fan community.", "敬意を持って。これはファンコミュニティです。")}
              {blockedUsers.length > 0 && (
                <span className="ml-2">
                  | {blockedUsers.length} {t("user(s) blocked", "ユーザーをブロック中")}
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Chat Messages */}
        <div className="terminal-border bg-[#0d0d0d] p-4 mb-6 h-[400px] overflow-y-auto">
          {loading ? (
            <div className="flex items-center justify-center h-full">
              <span className="text-[#0088FF] animate-pulse">
                {t("LOADING TRANSMISSIONS...", "送信を読み込み中...")}
              </span>
            </div>
          ) : visibleMessages.length === 0 ? (
            <div className="flex items-center justify-center h-full text-[#4a4a4a]">
              {t("No messages yet. Start the conversation!", "メッセージはまだありません。会話を始めましょう！")}
            </div>
          ) : (
            <div className="space-y-4">
              {visibleMessages.map((msg) => {
                const displayContent = msg.translatedContent || msg.content

                return (
                  <div key={msg.id} className="border-b border-[#1a1a1a] pb-4 last:border-0 last:pb-0 group">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3 mb-2">
                        <span className="text-[#00FF41] text-sm font-bold">{msg.profiles?.codename || "ANON"}</span>
                        <span className="text-[#4a4a4a] text-xs">
                          {new Date(msg.created_at).toLocaleString(language === "jp" ? "ja-JP" : "en-US")}
                        </span>
                        {msg.profiles?.is_admin && (
                          <span className="text-[#FF0000] text-xs">[{t("AUTHOR", "著者")}]</span>
                        )}
                      </div>
                      <div className="flex items-center gap-2">
                        {user && !msg.translatedContent && !msg.isTranslating && (
                          <button
                            onClick={() => handleTranslate(msg.id, msg.content)}
                            className="text-[#0088FF] text-xs opacity-0 group-hover:opacity-100 transition-opacity hover:text-[#00FF41]"
                          >
                            [{t("TRANSLATE", "翻訳")}]
                          </button>
                        )}
                        {user && msg.author_id !== user.id && !msg.profiles?.is_admin && (
                          <div className="relative">
                            <button
                              onClick={() => setShowBlockMenu(showBlockMenu === msg.id ? null : msg.id)}
                              className="text-[#4a4a4a] text-xs opacity-0 group-hover:opacity-100 transition-opacity hover:text-[#FF0000]"
                            >
                              [...]
                            </button>
                            {showBlockMenu === msg.id && (
                              <div className="absolute right-0 top-6 z-10 terminal-border bg-[#0a0a0a] p-2">
                                <button
                                  onClick={() => handleBlockUser(msg.author_id)}
                                  className="text-[#FF0000] text-xs hover:underline whitespace-nowrap"
                                >
                                  [{t("BLOCK USER", "ユーザーをブロック")}]
                                </button>
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                    <p className="text-[#0088FF] text-sm pl-0">
                      {msg.isTranslating ? (
                        <span className="animate-pulse">{t("Translating...", "翻訳中...")}</span>
                      ) : (
                        displayContent
                      )}
                    </p>
                    {msg.translatedContent && msg.translatedContent !== msg.content && (
                      <p className="text-[#4a4a4a] text-xs mt-1 italic">
                        {t("Original", "原文")}: {msg.content}
                      </p>
                    )}
                  </div>
                )
              })}
              <div ref={messagesEndRef} />
            </div>
          )}
        </div>

        {/* Input Form */}
        {user && profile ? (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="terminal-border bg-[#0a0a0a] p-4">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-[#00FF41] text-xs">{profile.codename}</span>
                <span className="text-[#4a4a4a] text-xs">{">"}</span>
              </div>
              <div className="flex gap-4">
                <input
                  type="text"
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  placeholder={t("TYPE_YOUR_MESSAGE...", "メッセージを入力...")}
                  className="flex-1 bg-transparent text-[#0088FF] text-sm outline-none placeholder:text-[#2a2a2a]"
                />
                <button
                  type="submit"
                  disabled={sending || !newMessage.trim()}
                  className="terminal-border-green bg-[#0a0a0a] px-6 py-2 text-[#00FF41] text-xs tracking-wider hover:bg-[#00FF41] hover:text-[#0a0a0a] transition-all disabled:opacity-50"
                >
                  {sending ? "..." : t("[TRANSMIT]", "[送信]")}
                </button>
              </div>
            </div>
          </form>
        ) : (
          <div className="terminal-border bg-[#0a0a0a] p-6 text-center">
            <p className="text-[#4a4a4a] text-sm mb-4">
              {t("You must be logged in to participate in the chat.", "チャットに参加するにはログインが必要です。")}
            </p>
            <a
              href="/auth/login"
              className="inline-block terminal-border-green px-6 py-3 text-[#00FF41] text-sm tracking-wider hover:bg-[#00FF41] hover:text-[#0a0a0a] transition-all"
            >
              {t("[LOGIN TO CHAT]", "[ログインしてチャット]")}
            </a>
          </div>
        )}

        {/* Blocked Users Panel */}
        {user && blockedUsers.length > 0 && (
          <div className="terminal-border bg-[#0a0a0a] p-4 mt-6">
            <h3 className="text-[#FF0000] text-xs tracking-wider mb-3">
              // {t("BLOCKED USERS", "ブロック中のユーザー")}
            </h3>
            <div className="flex flex-wrap gap-2">
              {messages
                .filter((m) => blockedUsers.includes(m.author_id))
                .filter((m, i, arr) => arr.findIndex((a) => a.author_id === m.author_id) === i)
                .map((msg) => (
                  <div
                    key={msg.author_id}
                    className="terminal-border bg-[#0d0d0d] px-3 py-2 flex items-center gap-2 text-xs"
                  >
                    <span className="text-[#4a4a4a]">{msg.profiles?.codename}</span>
                    <button onClick={() => handleUnblockUser(msg.author_id)} className="text-[#00FF41] hover:underline">
                      [{t("UNBLOCK", "解除")}]
                    </button>
                  </div>
                ))}
            </div>
          </div>
        )}

        {/* Network Status */}
        <div className="terminal-border bg-[#0a0a0a] p-4 mt-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs">
            <div>
              <span className="text-[#4a4a4a]">{t("ENCRYPTION", "暗号化")}:</span>
              <span className="text-[#00FF41] ml-2">E2E</span>
            </div>
            <div>
              <span className="text-[#4a4a4a]">{t("PROTOCOL", "プロトコル")}:</span>
              <span className="text-[#0088FF] ml-2">REALTIME</span>
            </div>
            <div>
              <span className="text-[#4a4a4a]">{t("UPTIME", "稼働時間")}:</span>
              <span className="text-[#0088FF] ml-2">99.9%</span>
            </div>
            <div>
              <span className="text-[#4a4a4a]">{t("STATUS", "状態")}:</span>
              <span className="text-[#00FF41] ml-2">{t("CONNECTED", "接続済")}</span>
            </div>
          </div>
        </div>
      </div>

      <SystemFooter />
    </main>
  )
}
