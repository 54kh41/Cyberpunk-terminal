import { generateText } from "ai"
import { NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"

export async function POST(request: Request) {
  try {
    const supabase = await createClient()
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { text, targetLanguage } = await request.json()

    if (!text || !targetLanguage) {
      return NextResponse.json({ error: "Missing text or targetLanguage" }, { status: 400 })
    }

    const prompt =
      targetLanguage === "jp"
        ? `Translate the following text to Japanese. Only respond with the translation, nothing else:\n\n${text}`
        : `Translate the following Japanese text to English. Only respond with the translation, nothing else:\n\n${text}`

    const { text: translatedText } = await generateText({
      model: "openai/gpt-5-mini",
      prompt,
      maxOutputTokens: 1000,
    })

    return NextResponse.json({ translatedText })
  } catch (error) {
    console.error("Translation error:", error)
    return NextResponse.json({ error: "Translation failed" }, { status: 500 })
  }
}
