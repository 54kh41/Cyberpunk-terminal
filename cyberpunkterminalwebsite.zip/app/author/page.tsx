"use client"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { TerminalNav } from "@/components/terminal-nav"
import { SystemFooter } from "@/components/system-footer"
import { LanguageToggle } from "@/components/language-toggle"
import { useLanguage } from "@/lib/language-context"
import type { AuthorSettings } from "@/lib/types"

export default function AuthorPage() {
  const [settings, setSettings] = useState<AuthorSettings | null>(null)
  const [loading, setLoading] = useState(true)
  const { t, language } = useLanguage()

  useEffect(() => {
    const fetchAuthorSettings = async () => {
      const supabase = createClient()
      const { data } = await supabase.from("author_settings").select("*").limit(1).single()

      if (data) setSettings(data)
      setLoading(false)
    }
    fetchAuthorSettings()
  }, [])

  if (loading) {
    return (
      <main className="min-h-screen flex items-center justify-center">
        <span className="text-[#0088FF] animate-pulse">{t("LOADING...", "読み込み中...")}</span>
      </main>
    )
  }

  const socialLinks = [
    { url: settings?.facebook_url, icon: "📘", label: "Facebook" },
    { url: settings?.instagram_url, icon: "📷", label: "Instagram" },
    { url: settings?.tiktok_url, icon: "🎵", label: "TikTok" },
    { url: settings?.twitter_url, icon: "🐦", label: "X (Twitter)" },
    { url: settings?.youtube_url, icon: "📺", label: "YouTube" },
    { url: settings?.discord_url, icon: "💬", label: "Discord" },
  ].filter((link) => link.url)

  const platformLinks = [
    { url: settings?.royal_road_url, icon: "📖", label: "Royal Road" },
    { url: settings?.kakuyomu_url, icon: "📚", label: "Kakuyomu" },
  ].filter((link) => link.url)

  return (
    <main className="min-h-screen pb-20">
      <LanguageToggle />
      <div className="max-w-5xl mx-auto p-4 md:p-6">
        <TerminalNav />

        {/* Banner */}
        {settings?.banner_url && (
          <div className="terminal-border mb-6 overflow-hidden">
            <img
              src={settings.banner_url || "/placeholder.svg"}
              alt="Banner"
              className="w-full h-48 md:h-64 object-cover"
            />
          </div>
        )}

        {/* Author Info Card */}
        <div className="terminal-border bg-[#0a0a0a] p-6 mb-6">
          <div className="flex flex-col md:flex-row items-center md:items-start gap-6">
            {/* Avatar */}
            {settings?.avatar_url ? (
              <img
                src={settings.avatar_url || "/placeholder.svg"}
                alt="Author"
                className="w-32 h-32 rounded-full object-cover border-4 border-[#0088FF] glow-border"
              />
            ) : (
              <div className="w-32 h-32 rounded-full bg-[#111] border-4 border-[#0088FF] flex items-center justify-center">
                <span className="text-[#0088FF] text-4xl">◈</span>
              </div>
            )}

            {/* Info */}
            <div className="flex-1 text-center md:text-left">
              <h1 className="text-[#00FF41] text-2xl md:text-3xl tracking-widest glow-text mb-2">
                {language === "jp" && settings?.display_name_jp
                  ? settings.display_name_jp
                  : settings?.display_name_en || t("AUTHOR", "著者")}
              </h1>
              <p className="text-[#4a4a4a] text-xs mb-4">
                // {t("CREATOR OF", "作者")} <span className="text-[#0088FF]">The Calculus Of A Shattered Soul</span>
              </p>

              {(settings?.bio_en || settings?.bio_jp) && (
                <div className="terminal-border bg-[#0d0d0d] p-4 text-[#c0c0c0] text-sm leading-relaxed">
                  {language === "jp" && settings?.bio_jp ? settings.bio_jp : settings?.bio_en}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Social Links */}
        {socialLinks.length > 0 && (
          <div className="terminal-border bg-[#0a0a0a] p-6 mb-6">
            <h2 className="text-[#0088FF] text-lg tracking-wider mb-4">// {t("CONNECT", "接続")}</h2>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {socialLinks.map(({ url, icon, label }) => (
                <a
                  key={label}
                  href={url!}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="terminal-border bg-[#0d0d0d] p-4 flex items-center gap-3 hover:bg-[#111] transition-all"
                >
                  <span className="text-xl">{icon}</span>
                  <span className="text-[#00FF41] text-sm">{label}</span>
                </a>
              ))}
            </div>
          </div>
        )}

        {/* Platform Links */}
        {platformLinks.length > 0 && (
          <div className="terminal-border-green bg-[#0a0a0a] p-6 mb-6">
            <h2 className="text-[#00FF41] text-lg tracking-wider mb-4">// {t("READ THE NOVEL", "小説を読む")}</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {platformLinks.map(({ url, icon, label }) => (
                <a
                  key={label}
                  href={url!}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="terminal-border-green bg-[#0d0d0d] p-6 flex items-center gap-4 hover:bg-[#00FF41] hover:text-[#0a0a0a] transition-all group"
                >
                  <span className="text-2xl">{icon}</span>
                  <div>
                    <span className="text-[#00FF41] text-lg group-hover:text-[#0a0a0a]">{label}</span>
                    <p className="text-[#4a4a4a] text-xs group-hover:text-[#0a0a0a]">
                      {t("Read on", "で読む")} {label}
                    </p>
                  </div>
                </a>
              ))}
            </div>
          </div>
        )}

        {/* No Settings Message */}
        {!settings && (
          <div className="terminal-border bg-[#0a0a0a] p-8 text-center">
            <p className="text-[#4a4a4a]">
              {t("Author profile not set up yet.", "著者プロフィールはまだ設定されていません。")}
            </p>
          </div>
        )}
      </div>

      <SystemFooter />
    </main>
  )
}
