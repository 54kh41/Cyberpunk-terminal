"use client"

import { useState } from "react"
import { TerminalNav } from "@/components/terminal-nav"
import { SystemFooter } from "@/components/system-footer"
import { BootSequence } from "@/components/boot-sequence"
import { WelcomeScreen } from "@/components/welcome-screen"
import { LanguageToggle } from "@/components/language-toggle"
import { PostsFeed } from "@/components/posts-feed"
import { useLanguage } from "@/lib/language-context"

type Phase = "welcome" | "boot" | "main"

export default function Home() {
  const [phase, setPhase] = useState<Phase>("welcome")
  const { t } = useLanguage()

  if (phase === "welcome") {
    return (
      <>
        <LanguageToggle />
        <WelcomeScreen onComplete={() => setPhase("boot")} />
      </>
    )
  }

  if (phase === "boot") {
    return (
      <>
        <LanguageToggle />
        <BootSequence onComplete={() => setPhase("main")} />
      </>
    )
  }

  return (
    <main className="min-h-screen pb-20">
      <LanguageToggle />
      <div className="max-w-5xl mx-auto p-4 md:p-6">
        <TerminalNav />

        {/* System Header */}
        <div className="terminal-border bg-[#0a0a0a] p-4 mb-6">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div className="space-y-1">
              <h1 className="text-[#00FF41] text-xl md:text-2xl tracking-widest glow-text">
                // {t("TRANSMISSION_FEED", "送信フィード")}
              </h1>
              <p className="text-[#4a4a4a] text-xs">
                {t("AUTHOR_BROADCASTS", "著者からの放送")} // {t("PRIORITY_LEVEL", "優先度")}:{" "}
                <span className="text-[#0088FF]">{t("PUBLIC", "公開")}</span>
              </p>
            </div>
            <div className="text-right text-xs space-y-1">
              <div className="text-[#4a4a4a]">
                {t("CHANNEL_STATUS", "チャンネル状態")}: <span className="text-[#00FF41]">{t("OPEN", "オープン")}</span>
              </div>
              <div className="text-[#4a4a4a]">
                {t("OBSERVERS", "観察者")}: <span className="text-[#0088FF]">--</span>
              </div>
            </div>
          </div>
        </div>

        {/* Posts Feed */}
        <PostsFeed />
      </div>

      <SystemFooter />
    </main>
  )
}
