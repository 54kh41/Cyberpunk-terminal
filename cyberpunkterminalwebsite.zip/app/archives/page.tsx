"use client"

import { TerminalNav } from "@/components/terminal-nav"
import { SystemFooter } from "@/components/system-footer"
import { LanguageToggle } from "@/components/language-toggle"
import { useLanguage } from "@/lib/language-context"

const dossiers = [
  {
    id: "DOSSIER_001",
    subject_en: "KEIJI ISHIDA",
    subject_jp: "石田 慧二",
    classification: "ALPHA",
    status_en: "ACTIVE_SURVEILLANCE",
    status_jp: "監視中",
    threat: "HIGH",
    summary_en:
      "Primary target. Student Council member. Exhibits extreme social influence over Class Y. All members defer to his judgment before taking action.",
    summary_jp:
      "主要ターゲット。生徒会メンバー。クラスYに対して極めて強い社会的影響力を持つ。全メンバーが行動前に彼の判断を仰ぐ。",
    tags: ["LEADER", "MANIPULATOR", "HIGH_PRIORITY"],
  },
  {
    id: "DOSSIER_002",
    subject_en: "SHIRASAKI [UNKNOWN]",
    subject_jp: "白崎 [不明]",
    classification: "BETA",
    status_en: "UNDER_INVESTIGATION",
    status_jp: "調査中",
    threat: "EXTREME",
    summary_en:
      "Secondary target. Always maintains exactly 3 steps behind Ishida. Role unclear - possibly enforcer or protector. Demonstrated awareness of surveillance.",
    summary_jp:
      "二次ターゲット。常に石田の3歩後ろを維持。役割不明 - 執行者または護衛の可能性。監視への認識を示している。",
    tags: ["UNKNOWN_ENTITY", "DANGEROUS", "OBSERVANT"],
  },
  {
    id: "DOSSIER_003",
    subject_en: "SUZUKI YUI",
    subject_jp: "鈴木 結衣",
    classification: "OMEGA",
    status_en: "OPERATIVE",
    status_jp: "工作員",
    threat: "NONE",
    summary_en:
      "Field operative. Assigned to Class Y infiltration. Reporting directly to Ashiro. Shows signs of stress. Reliability: 78%",
    summary_jp: "現場工作員。クラスY潜入任務に配属。芦代に直接報告。ストレスの兆候あり。信頼性: 78%",
    tags: ["INSIDER", "ASSET", "MONITORED"],
  },
  {
    id: "DOSSIER_004",
    subject_en: "CLASS Y COLLECTIVE",
    subject_jp: "クラスY集合体",
    classification: "GAMMA",
    status_en: "ANALYSIS_ONGOING",
    status_jp: "分析継続中",
    threat: "UNKNOWN",
    summary_en:
      "Entire class operates as unified entity. Synchronized behavior patterns. No individual deviation observed. Origin of coordination unknown.",
    summary_jp: "クラス全体が統一体として機能。同期された行動パターン。個人的な逸脱は観察されず。連携の起源は不明。",
    tags: ["HIVEMIND", "ANOMALY", "INVESTIGATION_REQUIRED"],
  },
]

export default function ArchivesPage() {
  const { t, language } = useLanguage()

  return (
    <main className="min-h-screen pb-20">
      <LanguageToggle />
      <div className="max-w-5xl mx-auto p-4 md:p-6">
        <TerminalNav />

        {/* Header */}
        <div className="terminal-border bg-[#0a0a0a] p-4 mb-6">
          <div className="space-y-1">
            <h1 className="text-[#00FF41] text-xl md:text-2xl tracking-widest glow-text">
              // {t("S.O.U.L._DATABASE", "S.O.U.L.データベース")}
            </h1>
            <p className="text-[#4a4a4a] text-xs">
              {t("INTELLIGENCE_DOSSIERS", "諜報ファイル")} // {t("CLASSIFICATION", "分類")}:{" "}
              <span className="text-[#FF0000]">{t("TOP_SECRET", "極秘")}</span>
            </p>
          </div>
        </div>

        {/* Database Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          {[
            { label_en: "TOTAL_FILES", label_jp: "総ファイル数", value: "127", color: "text-[#0088FF]" },
            { label_en: "ACTIVE_TARGETS", label_jp: "監視対象", value: "4", color: "text-[#00FF41]" },
            { label_en: "PENDING_ANALYSIS", label_jp: "分析待ち", value: "23", color: "text-[#4a4a4a]" },
            { label_en: "THREAT_ALERTS", label_jp: "脅威警報", value: "7", color: "text-[#FF0000]" },
          ].map((stat) => (
            <div key={stat.label_en} className="terminal-border bg-[#0d0d0d] p-4">
              <div className="text-[#4a4a4a] text-xs mb-1">{language === "jp" ? stat.label_jp : stat.label_en}</div>
              <div className={`${stat.color} text-2xl font-bold`}>{stat.value}</div>
            </div>
          ))}
        </div>

        {/* Dossiers */}
        <div className="space-y-4">
          {dossiers.map((dossier) => (
            <div
              key={dossier.id}
              className="terminal-border bg-[#0d0d0d] p-6 hover:bg-[#111111] transition-colors cursor-pointer group"
            >
              <div className="flex items-start justify-between gap-4 flex-wrap">
                <div className="space-y-2">
                  <div className="flex items-center gap-3">
                    <span className="text-[#4a4a4a] text-xs">[{dossier.id}]</span>
                    <h2 className="text-[#00FF41] text-lg tracking-wider group-hover:glow-text transition-all">
                      {language === "jp" ? dossier.subject_jp : dossier.subject_en}
                    </h2>
                  </div>
                  <div className="flex items-center gap-4 text-xs">
                    <span className="text-[#4a4a4a]">
                      {t("CLASS", "クラス")}: <span className="text-[#0088FF]">{dossier.classification}</span>
                    </span>
                    <span className="text-[#4a4a4a]">
                      {t("STATUS", "状態")}:{" "}
                      <span className="text-[#00FF41]">
                        {language === "jp" ? dossier.status_jp : dossier.status_en}
                      </span>
                    </span>
                    <span className="text-[#4a4a4a]">
                      {t("THREAT", "脅威")}:{" "}
                      <span
                        className={
                          dossier.threat === "EXTREME" || dossier.threat === "HIGH"
                            ? "text-[#FF0000]"
                            : "text-[#0088FF]"
                        }
                      >
                        {dossier.threat}
                      </span>
                    </span>
                  </div>
                </div>
                <div className="text-[#4a4a4a] text-xs group-hover:text-[#0088FF] transition-colors">
                  [{t("ACCESS_FILE", "ファイルアクセス")} ▶]
                </div>
              </div>

              <p className="text-[#0088FF] text-sm mt-4 leading-relaxed">
                {language === "jp" ? dossier.summary_jp : dossier.summary_en}
              </p>

              <div className="flex items-center gap-2 mt-4 flex-wrap">
                {dossier.tags.map((tag) => (
                  <span
                    key={tag}
                    className="text-xs px-2 py-1 border border-[#1a1a1a] text-[#4a4a4a] hover:border-[#0088FF] hover:text-[#0088FF] transition-colors"
                  >
                    #{tag}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Load More */}
        <div className="terminal-border bg-[#0a0a0a] p-4 mt-6 text-center">
          <button className="text-[#0088FF] text-xs tracking-wider hover:text-[#00FF41] transition-colors">
            [{t("LOAD_MORE_DOSSIERS", "さらにファイルを読み込む")}]{" "}
            <span className="text-[#4a4a4a]">// 123 {t("remaining", "残り")}</span>
          </button>
        </div>
      </div>

      <SystemFooter />
    </main>
  )
}
