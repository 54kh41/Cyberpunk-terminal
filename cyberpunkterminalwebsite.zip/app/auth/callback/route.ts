import { createClient } from "@/lib/supabase/server"
import { NextResponse } from "next/server"

export async function GET(request: Request) {
  const requestUrl = new URL(request.url)
  const code = requestUrl.searchParams.get("code")

  if (code) {
    const supabase = await createClient()
    const {
      data: { user },
      error,
    } = await supabase.auth.exchangeCodeForSession(code)

    // If user signed up, create their profile
    if (user && !error) {
      const codename =
        user.user_metadata?.codename ||
        user.user_metadata?.full_name?.toUpperCase().replace(/\s+/g, "_") ||
        user.user_metadata?.name?.toUpperCase().replace(/\s+/g, "_") ||
        `USER_${user.id.slice(0, 8).toUpperCase()}`

      // Check if profile exists
      const { data: existingProfile } = await supabase.from("profiles").select("id").eq("id", user.id).single()

      if (!existingProfile) {
        await supabase.from("profiles").insert({
          id: user.id,
          codename: codename,
          is_admin: false,
          language_preference: "en",
        })
      }
    }
  }

  return NextResponse.redirect(requestUrl.origin)
}
