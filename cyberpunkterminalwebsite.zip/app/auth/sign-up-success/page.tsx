"use client"

import Link from "next/link"
import { LanguageToggle } from "@/components/language-toggle"
import { useLanguage } from "@/lib/language-context"

export default function SignUpSuccessPage() {
  const { t } = useLanguage()

  return (
    <main className="min-h-screen flex items-center justify-center p-4">
      <LanguageToggle />
      <div className="w-full max-w-md">
        <div className="terminal-border-green bg-[#0a0a0a] p-8 text-center">
          <div className="text-[#00FF41] text-6xl mb-6">✓</div>
          <h1 className="text-[#00FF41] text-2xl tracking-wider glow-text mb-4">
            {t("REGISTRATION COMPLETE", "登録完了")}
          </h1>
          <p className="text-[#0088FF] text-sm mb-6">
            {t(
              "Check your email to verify your account before logging in.",
              "ログインする前にメールを確認してアカウントを認証してください。",
            )}
          </p>
          <Link
            href="/auth/login"
            className="inline-block terminal-border px-6 py-3 text-[#0088FF] text-sm tracking-wider hover:text-[#00FF41] hover:border-[#00FF41] transition-all"
          >
            {t("[PROCEED TO LOGIN]", "[ログインへ進む]")}
          </Link>
        </div>
      </div>
    </main>
  )
}
